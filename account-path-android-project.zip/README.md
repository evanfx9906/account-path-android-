# Account Path native Android app

Offline-first native Android implementation of the Account Path two-profile trading tracker.

## Local build

Requirements: JDK 17, Android SDK platform 36, Android build-tools 36.0.0, and Gradle 8.13. The GitHub Actions workflow in the outer build kit installs these dependencies on a clean hosted runner.

From this project root, run:

```sh
gradle --no-daemon clean testDebugUnitTest assembleDebug
```

For a signed release build, set `ACCOUNT_PATH_KEYSTORE_FILE` to the absolute path of `signing/account-path-release.keystore`, set `ACCOUNT_PATH_SIGNING_PASSWORD` to the private password supplied separately, then run:

```sh
gradle --no-daemon clean testDebugUnitTest assembleRelease
```

The project uses Java only, Android's built-in SQLite database, and no runtime Internet permission. Runtime records belong in the phone's private app storage. The source archive contains an encrypted release keystore so releases from this project can use one stable signing identity; the keystore password must not be committed to source control.

## Data and backups

The app stores profile data and events in SQLite using transactions. It maintains two rotating on-device JSON recovery snapshots. Manual JSON backups can be exported/imported from Trade Log. Android app uninstall / clearing app storage deletes its local records, so external JSON backups are still necessary.

Backup exports from Account Path HTML versions 4–6 are accepted by `BackupCodec` when they follow the `profiles.slow` and `profiles.play` event-based schema. Browser `localStorage` is not accessible to this native app; export a JSON file from the HTML app before migrating when possible.

## Project facts

- Package/application ID: `com.accountpath.mobile`
- Minimum Android version: API 26 (Android 8.0)
- Compile SDK: API 36
- Target SDK: API 35
- Language: Java 17
- Gradle: 8.13
- Android Gradle Plugin: 8.13.2
- No third-party app runtime dependencies; JUnit 4 is used for local unit tests.
