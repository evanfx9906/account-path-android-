package com.accountpath.mobile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** JSON format compatible with Account Path v4-v6 profile backups. */
public final class BackupCodec {
    private BackupCodec() {}

    public static JSONObject exportRoot(List<ProfileData> profiles, long generation,
                                        String activeProfile, String activeTab) throws JSONException {
        JSONObject root = new JSONObject();
        root.put("version", 7);
        root.put("backupVersion", 7);
        root.put("exportedAt", java.time.Instant.now().toString());
        root.put("localGeneration", generation);
        root.put("activeProfile", "play".equals(activeProfile) ? "play" : "slow");
        root.put("activeTab", validTab(activeTab) ? activeTab : "goal");
        JSONObject ps = new JSONObject();
        for (String id : new String[]{"slow", "play"}) {
            ProfileData p = findProfile(profiles, id);
            if (p == null) p = new ProfileData(id);
            JSONObject obj = new JSONObject();
            if (p.initialCapital == null) obj.put("initialCapital", JSONObject.NULL);
            else obj.put("initialCapital", p.initialCapital);
            obj.put("currency", cleanCurrency(p.currency));
            obj.put("targetProfit", p.targetProfit == null ? "" : p.targetProfit);
            obj.put("cycleId", p.cycleId == null ? UUID.randomUUID().toString() : p.cycleId);
            JSONArray events = new JSONArray();
            for (TradeEvent e : p.events) {
                JSONObject entry = new JSONObject();
                entry.put("id", e.id);
                entry.put("date", e.date);
                entry.put("kind", e.kind);
                entry.put("amount", Double.toString(e.amount));
                entry.put("createdAt", e.createdAt);
                events.put(entry);
            }
            obj.put("events", events);
            ps.put(id, obj);
        }
        root.put("profiles", ps);
        return root;
    }

    public static ProfileData parseProfile(String id, JSONObject raw) throws JSONException {
        if (!"slow".equals(id) && !"play".equals(id)) throw new JSONException("Unknown profile.");
        if (raw == null) throw new JSONException("The backup is missing the " + id + " profile.");
        ProfileData p = new ProfileData(id);
        if (raw.has("initialCapital") && !raw.isNull("initialCapital")) {
            double capital = number(raw.get("initialCapital"), "starting capital");
            if (!Double.isFinite(capital) || capital <= 0) throw new JSONException("Starting capital must be greater than zero or empty.");
            p.initialCapital = capital;
        } else {
            p.initialCapital = null;
        }
        p.currency = cleanCurrency(raw.optString("currency", "€"));
        Object target = raw.opt("targetProfit");
        p.targetProfit = (target == null || target == JSONObject.NULL) ? "" : String.valueOf(target);
        p.cycleId = raw.optString("cycleId", "").trim();
        if (p.cycleId.isEmpty()) p.cycleId = UUID.randomUUID().toString();

        JSONArray events = raw.optJSONArray("events");
        Set<String> seen = new HashSet<>();
        if (events != null) {
            for (int i = 0; i < events.length(); i++) {
                JSONObject e = events.optJSONObject(i);
                if (e == null) throw new JSONException("Event " + (i + 1) + " is not a JSON object.");
                String eventId = e.optString("id", "").trim();
                if (eventId.isEmpty()) eventId = UUID.randomUUID().toString();
                if (!seen.add(eventId)) continue; // Deduplicate repeated snapshots defensively.
                String date = e.optString("date", "");
                String kind = e.optString("kind", "");
                double amount = number(e.opt("amount"), "event amount");
                long createdAt = e.has("createdAt") ? safeLong(e.opt("createdAt"), i) : i;
                TradeEvent event = new TradeEvent(eventId, date, kind, amount, createdAt);
                if (!event.isValid()) throw new JSONException("Event " + (i + 1) + " has an invalid date, amount or type.");
                p.events.add(event);
            }
        }
        AccountSnapshot validation = AccountEngine.calculate(p);
        if (validation.error != null) throw new JSONException(validation.error);
        return p;
    }

    public static List<ProfileData> parseAll(JSONObject root) throws JSONException {
        if (root == null) throw new JSONException("The file is empty.");
        JSONObject ps = root.optJSONObject("profiles");
        if (ps == null) throw new JSONException("This is not an Account Path profile backup. Older balance snapshots cannot safely be treated as trades.");
        List<ProfileData> all = new ArrayList<>();
        all.add(parseProfile("slow", ps.optJSONObject("slow")));
        all.add(parseProfile("play", ps.optJSONObject("play")));
        return all;
    }

    public static JSONObject profileFromRoot(JSONObject root, String id) {
        if (root == null) return null;
        JSONObject profiles = root.optJSONObject("profiles");
        return profiles == null ? null : profiles.optJSONObject(id);
    }

    private static ProfileData findProfile(List<ProfileData> profiles, String id) {
        if (profiles == null) return null;
        for (ProfileData p : profiles) if (p != null && id.equals(p.id)) return p;
        return null;
    }

    private static double number(Object value, String label) throws JSONException {
        if (value == null || value == JSONObject.NULL) throw new JSONException("Missing " + label + ".");
        String s = String.valueOf(value).trim().replace(" ", "");
        if (s.isEmpty()) throw new JSONException("Missing " + label + ".");
        // Accept Greek-style decimal commas as well as standard decimal points.
        if (s.indexOf(',') >= 0 && s.indexOf('.') >= 0) {
            if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(".", "").replace(',', '.');
            else s = s.replace(",", "");
        } else if (s.indexOf(',') >= 0) {
            s = s.replace(',', '.');
        }
        try { return Double.parseDouble(s); }
        catch (RuntimeException ex) { throw new JSONException("Invalid " + label + "."); }
    }

    private static long safeLong(Object value, long fallback) {
        try { return (long) Double.parseDouble(String.valueOf(value)); }
        catch (RuntimeException ex) { return fallback; }
    }

    private static String cleanCurrency(String value) {
        String s = value == null ? "€" : value.trim();
        if (s.isEmpty()) s = "€";
        return s.length() > 8 ? s.substring(0, 8) : s;
    }

    private static boolean validTab(String tab) {
        return "goal".equals(tab) || "forecast".equals(tab) || "log".equals(tab);
    }
}
