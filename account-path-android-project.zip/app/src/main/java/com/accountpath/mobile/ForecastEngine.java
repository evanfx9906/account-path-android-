package com.accountpath.mobile;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/** Deterministic, profile-local block-bootstrap scenarios with calendar-date translation. */
public final class ForecastEngine {
    public static final int MIN_OUTCOMES = 20;
    public static final int COMFORT_OUTCOMES = 60;
    public static final int MAX_SIMULATED_OUTCOMES = 1000;
    private static final int SIMULATIONS = 700;
    private static final int BLOCK_LENGTH = 3;
    private static final double EPS = 1e-8;
    private ForecastEngine() {}

    public static final class Cadence {
        public boolean ready;
        public String reason;
        public String firstDate = "";
        public String lastDate = "";
        public int uniqueDates;
        public int records;
        public long spanDays;
        public double tradesPerWeek;
    }

    public static final class Stats {
        public int outcomes;
        public int wins;
        public int losses;
        public double winRate = Double.NaN;
        public double averageWin = Double.NaN;
        public double averageLoss = Double.NaN;
        public double payoff = Double.NaN;
        public double expectancy = Double.NaN;
        public double simpleReturnSd = Double.NaN;
        public String consistency = "Not enough data";
        public int positiveWeeks;
        public int negativeWeeks;
        public int flatWeeks;
        public int totalWeeks;
        public int bestWinStreak;
        public int bestLossStreak;
        public int currentStreak;
        public String currentStreakKind = "";
        public double largestWin = Double.NaN;
        public double largestLoss = Double.NaN;
    }

    public static final class Estimate {
        public boolean ready;
        public boolean alreadyReached;
        public String reason = "";
        public String earlierDate = "—";
        public String typicalDate = "—";
        public String slowerDate = "—";
        public String earlierDetail = "";
        public String typicalDetail = "";
        public String slowerDetail = "";
        public int outcomesNeeded;
        public int simulations = SIMULATIONS;
    }

    private static final class Prepared {
        double[] centered;
        double sd;
        int clipped;
        double mean;
    }

    public static Cadence cadence(AccountSnapshot d) {
        Cadence c = new Cadence();
        LocalDate today = LocalDate.now();
        List<LocalDate> dates = new ArrayList<>();
        for (AccountSnapshot.ReturnSample sample : d.returns) {
            try {
                LocalDate date = LocalDate.parse(sample.date);
                if (!date.isAfter(today)) dates.add(date);
            } catch (RuntimeException ignored) { }
        }
        dates.sort(Comparator.naturalOrder());
        List<LocalDate> unique = new ArrayList<>();
        for (LocalDate date : dates) if (unique.isEmpty() || !unique.get(unique.size() - 1).equals(date)) unique.add(date);
        c.records = dates.size(); c.uniqueDates = unique.size();
        if (unique.size() < 3) {
            c.reason = "Log wins/losses on at least three different dates to estimate your pace.";
            return c;
        }
        LocalDate first = unique.get(0), last = unique.get(unique.size() - 1);
        c.firstDate = first.toString(); c.lastDate = last.toString();
        c.spanDays = ChronoUnit.DAYS.between(first, last) + 1L;
        if (c.spanDays < 14) {
            c.reason = "Your dated trading history needs to span at least 14 calendar days.";
            return c;
        }
        double weeks = c.spanDays / 7.0;
        c.tradesPerWeek = c.records / weeks;
        if (!Double.isFinite(c.tradesPerWeek) || c.tradesPerWeek <= 0) {
            c.reason = "There is not enough dated history to estimate your trading pace.";
            return c;
        }
        c.ready = true;
        c.reason = "";
        return c;
    }

    public static Stats stats(ProfileData profile, AccountSnapshot d) {
        Stats s = new Stats();
        s.wins = d.wins; s.losses = d.losses; s.outcomes = d.wins + d.losses;
        if (s.outcomes > 0) s.winRate = (double) s.wins / s.outcomes;
        s.averageWin = mean(d.winAmounts);
        s.averageLoss = mean(d.lossAmounts);
        if (Double.isFinite(s.averageWin) && Double.isFinite(s.averageLoss) && s.averageLoss > 0) s.payoff = s.averageWin / s.averageLoss;
        if (s.outcomes > 0) s.expectancy = d.netTrading / s.outcomes;
        if (d.winAmounts.size() > 0) s.largestWin = max(d.winAmounts);
        if (d.lossAmounts.size() > 0) s.largestLoss = max(d.lossAmounts);

        List<Double> simpleReturns = new ArrayList<>();
        for (AccountSnapshot.ReturnSample r : d.returns) {
            double v = Math.exp(Math.max(-30, Math.min(30, r.logReturn))) - 1.0;
            if (Double.isFinite(v)) simpleReturns.add(v);
        }
        s.simpleReturnSd = standardDeviation(simpleReturns);
        if (d.returns.size() >= 10 && Double.isFinite(s.simpleReturnSd)) {
            s.consistency = s.simpleReturnSd < 0.05 ? "Tighter spread" : s.simpleReturnSd < 0.15 ? "Mixed spread" : "Wide spread";
        }

        Map<String, Double> weeklyNet = new TreeMap<>();
        for (TradeEvent e : d.sortedEvents) {
            if (!"win".equals(e.kind) && !"loss".equals(e.kind)) continue;
            try {
                LocalDate date = LocalDate.parse(e.date);
                int week = date.get(WeekFields.ISO.weekOfWeekBasedYear());
                int year = date.get(WeekFields.ISO.weekBasedYear());
                String key = String.format(Locale.ROOT, "%04d-W%02d", year, week);
                weeklyNet.put(key, weeklyNet.getOrDefault(key, 0.0) + ("win".equals(e.kind) ? e.amount : -e.amount));
            } catch (RuntimeException ignored) { }
        }
        s.totalWeeks = weeklyNet.size();
        for (double net : weeklyNet.values()) {
            if (net > EPS) s.positiveWeeks++;
            else if (net < -EPS) s.negativeWeeks++;
            else s.flatWeeks++;
        }

        int run = 0, bestW = 0, bestL = 0;
        String runKind = "";
        for (TradeEvent e : d.sortedEvents) {
            if (!"win".equals(e.kind) && !"loss".equals(e.kind)) continue;
            if (e.kind.equals(runKind)) run++;
            else { runKind = e.kind; run = 1; }
            if ("win".equals(runKind)) bestW = Math.max(bestW, run);
            else bestL = Math.max(bestL, run);
        }
        s.bestWinStreak = bestW; s.bestLossStreak = bestL; s.currentStreak = run; s.currentStreakKind = runKind;
        return s;
    }

    public static boolean isForecastReady(AccountSnapshot d, Cadence cadence) {
        if (!d.isSet || d.error != null || d.modelBalance <= 0 || d.returns.size() < MIN_OUTCOMES || cadence == null || !cadence.ready) return false;
        Prepared p = prepare(d.returns);
        return p != null && Double.isFinite(p.sd) && p.sd >= 0.005;
    }

    public static String notReadyReason(AccountSnapshot d, Cadence cadence) {
        if (!d.isSet) return "Enter starting capital in Trade Log first.";
        if (d.error != null) return d.error;
        if (d.modelBalance <= 0) return "The trading-only reference balance is at zero. Forecasts are withheld until the next trading cycle.";
        if (d.returns.size() < MIN_OUTCOMES) return d.returns.size() + "/" + MIN_OUTCOMES + " valid win/loss outcomes. More observations are needed.";
        Prepared prep = prepare(d.returns);
        if (prep == null || !Double.isFinite(prep.sd) || prep.sd < 0.005) return "Observed outcomes vary too little to support a useful probability estimate. Forecast withheld.";
        if (cadence == null || !cadence.ready) return cadence == null ? "Not enough date history yet." : cadence.reason;
        return "Forecast is ready.";
    }

    public static Estimate estimate(ProfileData profile, AccountSnapshot d, double target) {
        Estimate estimate = new Estimate();
        if (!d.isSet || !Double.isFinite(target) || target <= 0) {
            estimate.reason = "Set starting capital and enter a valid target.";
            return estimate;
        }
        if (d.modelBalance >= target) {
            estimate.ready = true; estimate.alreadyReached = true;
            estimate.earlierDate = estimate.typicalDate = estimate.slowerDate = "Already reached";
            estimate.earlierDetail = estimate.typicalDetail = estimate.slowerDetail = "Trading-only path";
            return estimate;
        }
        Cadence cadence = cadence(d);
        if (!isForecastReady(d, cadence)) {
            estimate.reason = notReadyReason(d, cadence);
            estimate.outcomesNeeded = Math.max(0, MIN_OUTCOMES - d.returns.size());
            return estimate;
        }
        Prepared prep = prepare(d.returns);
        double[] hits = simulateOneTarget(d, prep, target, MAX_SIMULATED_OUTCOMES, SIMULATIONS);
        estimate.ready = true;
        estimate.earlierDate = dateForQuantile(quantile(hits, 0.10), cadence, estimate, true);
        estimate.typicalDate = dateForQuantile(quantile(hits, 0.50), cadence, estimate, false);
        estimate.slowerDate = dateForQuantile(quantile(hits, 0.90), cadence, estimate, false);
        estimate.earlierDetail = detailForQuantile(quantile(hits, 0.10), cadence);
        estimate.typicalDetail = detailForQuantile(quantile(hits, 0.50), cadence);
        estimate.slowerDetail = detailForQuantile(quantile(hits, 0.90), cadence);
        return estimate;
    }

    public static List<Estimate> estimateMany(ProfileData profile, AccountSnapshot d, double[] targets) {
        List<Estimate> output = new ArrayList<>();
        Cadence cadence = cadence(d);
        if (!isForecastReady(d, cadence)) {
            for (double target : targets) {
                Estimate e = new Estimate(); e.reason = notReadyReason(d, cadence); e.outcomesNeeded = Math.max(0, MIN_OUTCOMES - d.returns.size()); output.add(e);
            }
            return output;
        }
        Prepared prep = prepare(d.returns);
        List<double[]> hits = simulateManyTargets(d, prep, targets, MAX_SIMULATED_OUTCOMES, SIMULATIONS);
        for (int i = 0; i < targets.length; i++) {
            Estimate e = new Estimate();
            if (d.modelBalance >= targets[i]) {
                e.ready = true; e.alreadyReached = true;
                e.earlierDate = e.typicalDate = e.slowerDate = "Already reached";
                e.earlierDetail = e.typicalDetail = e.slowerDetail = "Trading-only path";
            } else {
                double[] h = hits.get(i); e.ready = true;
                double q10 = quantile(h, 0.10), q50 = quantile(h, 0.50), q90 = quantile(h, 0.90);
                e.earlierDate = dateForQuantile(q10, cadence, e, true);
                e.typicalDate = dateForQuantile(q50, cadence, e, false);
                e.slowerDate = dateForQuantile(q90, cadence, e, false);
                e.earlierDetail = detailForQuantile(q10, cadence);
                e.typicalDetail = detailForQuantile(q50, cadence);
                e.slowerDetail = detailForQuantile(q90, cadence);
            }
            output.add(e);
        }
        return output;
    }

    private static String dateForQuantile(double trades, Cadence cadence, Estimate estimate, boolean early) {
        if (trades <= 0) return "Already reached";
        if (!Double.isFinite(trades) || trades > MAX_SIMULATED_OUTCOMES) return "Beyond simulation range";
        double weeks = trades / cadence.tradesPerWeek;
        long days = Math.max(1L, Math.round(weeks * 7.0));
        LocalDate date = LocalDate.now().plusDays(days);
        return date.format(java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH));
    }

    private static String detailForQuantile(double trades, Cadence cadence) {
        if (trades <= 0) return "Based on trading-only balance";
        if (!Double.isFinite(trades) || trades > MAX_SIMULATED_OUTCOMES) return "Not reached within 1,000 simulated outcomes";
        double weeks = trades / cadence.tradesPerWeek;
        long days = Math.max(1L, Math.round(weeks * 7.0));
        String duration;
        if (weeks < 1.0) duration = "about " + days + (days == 1 ? " day" : " days");
        else if (weeks < 8.0) duration = "about " + String.format(Locale.ENGLISH, "%.1f weeks", weeks);
        else if (weeks / 4.345 < 24) duration = "about " + String.format(Locale.ENGLISH, "%.1f months", weeks / 4.345);
        else duration = "about " + String.format(Locale.ENGLISH, "%.1f years", weeks / 52.14);
        return duration + " · ~" + Math.round(trades) + " outcomes";
    }

    private static List<double[]> simulateManyTargets(AccountSnapshot d, Prepared prep, double[] targets, int maxTrades, int runs) {
        List<double[]> output = new ArrayList<>();
        for (int i = 0; i < targets.length; i++) {
            double[] values = new double[runs];
            for (int r = 0; r < runs; r++) values[r] = maxTrades + 1.0;
            output.add(values);
        }
        long seed = seedFor(prep.centered, d.modelBalance, targets, maxTrades, runs);
        Random random = new Random(seed);
        int n = prep.centered.length;
        for (int run = 0; run < runs; run++) {
            double balance = d.modelBalance;
            double[] hits = new double[targets.length];
            Arrays.fill(hits, maxTrades + 1.0);
            for (int t = 0; t < targets.length; t++) if (balance >= targets[t]) hits[t] = 0;
            int blockOffset = BLOCK_LENGTH;
            int blockStart = 0;
            for (int trade = 1; trade <= maxTrades; trade++) {
                if (blockOffset >= BLOCK_LENGTH) { blockStart = random.nextInt(n); blockOffset = 0; }
                double lr = clamp(prep.centered[(blockStart + blockOffset) % n], -18, 8);
                blockOffset++;
                double exponent = Math.max(-18.0, Math.min(8.0, lr));
                balance = Math.max(0.0, Math.min(1e100, balance * Math.exp(exponent)));
                for (int i = 0; i < targets.length; i++) if (hits[i] > maxTrades && balance >= targets[i]) hits[i] = trade;
            }
            for (int i = 0; i < targets.length; i++) output.get(i)[run] = hits[i];
        }
        return output;
    }

    private static double[] simulateOneTarget(AccountSnapshot d, Prepared prep, double target, int maxTrades, int runs) {
        return simulateManyTargets(d, prep, new double[]{target}, maxTrades, runs).get(0);
    }

    private static Prepared prepare(List<AccountSnapshot.ReturnSample> samples) {
        if (samples == null || samples.isEmpty()) return null;
        double[] raw = new double[samples.size()];
        for (int i = 0; i < samples.size(); i++) raw[i] = samples.get(i).logReturn;
        for (double v : raw) if (!Double.isFinite(v)) return null;
        double med = median(raw);
        double[] absDev = new double[raw.length]; for (int i = 0; i < raw.length; i++) absDev[i] = Math.abs(raw[i] - med);
        double mad = median(absDev), scale = 1.4826 * mad;
        double bound = Math.max(3.5 * scale, Math.log(1.5));
        double[] clipped = raw.clone(); int clipCount = 0;
        if (raw.length >= 3) {
            for (int i = 0; i < clipped.length; i++) {
                double v = clamp(clipped[i], med - bound, med + bound);
                if (Math.abs(v - clipped[i]) > 1e-12) clipCount++;
                clipped[i] = v;
            }
        }
        double avg = mean(clipped);
        double shrunkDrift = avg * clipped.length / (clipped.length + 20.0);
        Prepared p = new Prepared(); p.centered = new double[clipped.length]; p.mean = avg; p.clipped = clipCount;
        for (int i = 0; i < clipped.length; i++) p.centered[i] = clipped[i] - avg + shrunkDrift;
        p.sd = standardDeviation(toList(raw));
        return p;
    }

    private static long seedFor(double[] values, double current, double[] targets, int maxTrades, int runs) {
        long h = 0xcbf29ce484222325L;
        StringBuilder key = new StringBuilder();
        for (double v : values) key.append(String.format(Locale.ROOT, "%.8f|", v));
        key.append(current).append('|').append(maxTrades).append('|').append(runs);
        for (double target : targets) key.append('|').append(target);
        for (int i = 0; i < key.length(); i++) { h ^= key.charAt(i); h *= 0x100000001b3L; }
        return h;
    }

    private static List<Double> toList(double[] values) { List<Double> out = new ArrayList<>(); for (double v : values) out.add(v); return out; }
    private static double mean(List<Double> values) { if (values.isEmpty()) return Double.NaN; double sum = 0; for (double v : values) sum += v; return sum / values.size(); }
    private static double mean(double[] values) { if (values.length == 0) return Double.NaN; double sum = 0; for (double v : values) sum += v; return sum / values.length; }
    private static double max(List<Double> values) { double v = Double.NEGATIVE_INFINITY; for (double n : values) v = Math.max(v, n); return v; }
    private static double standardDeviation(List<Double> values) {
        if (values.size() < 2) return Double.NaN; double m = mean(values), sum = 0;
        for (double v : values) sum += (v - m) * (v - m);
        return Math.sqrt(sum / (values.size() - 1));
    }
    private static double median(double[] values) {
        if (values.length == 0) return Double.NaN; double[] sorted = values.clone(); Arrays.sort(sorted); int m = sorted.length / 2;
        return sorted.length % 2 == 0 ? (sorted[m - 1] + sorted[m]) / 2.0 : sorted[m];
    }
    private static double median(List<Double> values) { double[] a = new double[values.size()]; for (int i = 0; i < a.length; i++) a[i] = values.get(i); return median(a); }
    private static double quantile(double[] values, double q) {
        if (values.length == 0) return Double.NaN; double[] sorted = values.clone(); Arrays.sort(sorted);
        double pos = (sorted.length - 1) * q; int lo = (int) Math.floor(pos), hi = (int) Math.ceil(pos);
        return lo == hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
    }
    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
}
