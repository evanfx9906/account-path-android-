package com.accountpath.mobile;

import java.time.LocalDate;

/** One dated balance event. Manual adjustments never become model returns. */
public final class TradeEvent {
    public final String id;
    public final String date;
    public final String kind;
    public final double amount;
    public final long createdAt;

    public TradeEvent(String id, String date, String kind, double amount, long createdAt) {
        this.id = id == null || id.isEmpty() ? java.util.UUID.randomUUID().toString() : id;
        this.date = date == null ? "" : date;
        this.kind = kind == null ? "add" : kind;
        this.amount = amount;
        this.createdAt = createdAt;
    }

    public boolean isValid() {
        return amount > 0.0 && Double.isFinite(amount)
                && ("win".equals(kind) || "loss".equals(kind)
                || "add".equals(kind) || "subtract".equals(kind))
                && isValidDate(date);
    }

    public static boolean isValidDate(String value) {
        if (value == null) return false;
        try {
            LocalDate.parse(value);
            return value.length() == 10;
        } catch (RuntimeException ex) {
            return false;
        }
    }
}
