package com.accountpath.mobile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class ProfileData {
    public final String id;
    public Double initialCapital;
    public String currency;
    public String targetProfit;
    public String cycleId;
    public final List<TradeEvent> events = new ArrayList<>();

    public ProfileData(String id) {
        this.id = id;
        this.initialCapital = null;
        this.currency = "€";
        this.targetProfit = "";
        this.cycleId = UUID.randomUUID().toString();
    }

    public ProfileData copyWithoutEvents() {
        ProfileData p = new ProfileData(id);
        p.initialCapital = initialCapital;
        p.currency = currency;
        p.targetProfit = targetProfit;
        p.cycleId = cycleId;
        return p;
    }
}
