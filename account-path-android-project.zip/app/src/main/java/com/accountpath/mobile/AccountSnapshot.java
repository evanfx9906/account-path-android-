package com.accountpath.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AccountSnapshot {
    public boolean isSet;
    public double initialCapital;
    public double balance;
    public double modelBalance;
    public double netTrading;
    public double netManual;
    public double manualAdds;
    public double manualSubs;
    public int wins;
    public int losses;
    public String error;
    public final List<TradeEvent> sortedEvents = new ArrayList<>();
    public final List<ReturnSample> returns = new ArrayList<>();
    public final List<Double> winAmounts = new ArrayList<>();
    public final List<Double> lossAmounts = new ArrayList<>();
    public final Map<String, Double> balanceAfterByEvent = new HashMap<>();
    public final Map<String, Double> modelBalanceAfterByEvent = new HashMap<>();

    public static final class ReturnSample {
        public final double logReturn;
        public final String date;
        public final String eventId;
        public final double amount;
        public final String kind;
        public ReturnSample(double logReturn, String date, String eventId, double amount, String kind) {
            this.logReturn = logReturn;
            this.date = date;
            this.eventId = eventId;
            this.amount = amount;
            this.kind = kind;
        }
    }
}
