package com.accountpath.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Account Path: offline-first native Android account tracker. */
public final class MainActivity extends Activity {
    private static final int REQ_EXPORT = 701;
    private static final int REQ_RESTORE = 702;
    private static final int REQ_REBUILD = 703;

    private static final int BG = Color.rgb(11, 18, 32);
    private static final int CARD = Color.rgb(21, 31, 49);
    private static final int CARD_ALT = Color.rgb(27, 40, 61);
    private static final int TEXT = Color.rgb(241, 245, 249);
    private static final int MUTED = Color.rgb(155, 170, 190);
    private static final int MINT = Color.rgb(64, 224, 208);
    private static final int GREEN = Color.rgb(52, 211, 153);
    private static final int RED = Color.rgb(251, 113, 133);
    private static final int AMBER = Color.rgb(251, 191, 36);
    private static final int LINE = Color.rgb(53, 68, 91);

    private AppDatabase db;
    private SharedPreferences preferences;
    private String activeProfile = "slow";
    private String activeTab = "goal";
    private LocalDate selectedDate = LocalDate.now();
    private final Set<String> expandedWeeks = new HashSet<>();
    private LinearLayout outer;
    private LinearLayout profileButtons;
    private TextView slowProfileButton;
    private TextView playProfileButton;
    private TextView balanceTitle;
    private TextView balanceValue;
    private TextView balanceSub;
    private TextView profileStatus;
    private TextView messageView;
    private LinearLayout content;
    private LinearLayout goalTabButton;
    private LinearLayout forecastTabButton;
    private LinearLayout logTabButton;
    private String statusMessage = "";
    private boolean statusIsError;
    private String recoveryNotice = "";
    private String storageFailure = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        preferences = getSharedPreferences("account_path_view", MODE_PRIVATE);
        activeProfile = "play".equals(preferences.getString("activeProfile", "slow")) ? "play" : "slow";
        activeTab = validTab(preferences.getString("activeTab", "goal")) ? preferences.getString("activeTab", "goal") : "goal";
        initializeStorage();
        buildScaffold();
        refreshAll();
        if (!recoveryNotice.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Local recovery check")
                    .setMessage(recoveryNotice)
                    .setPositiveButton("OK", (d, w) -> { })
                    .show();
        }
        if (!storageFailure.isEmpty()) showMessage(storageFailure, true);
    }

    private void initializeStorage() {
        JSONObject recovery = readBestRecoveryRoot();
        try {
            db = new AppDatabase(this);
            db.getWritableDatabase();
        } catch (SQLiteException firstError) {
            try { if (db != null) db.close(); } catch (RuntimeException ignored) { }
            db = null;
            boolean moved = quarantineDatabaseFiles();
            try {
                db = new AppDatabase(this);
                db.getWritableDatabase();
                if (recovery != null) {
                    List<ProfileData> recovered = BackupCodec.parseAll(recovery);
                    db.replaceAllProfiles(recovered, recovery.optLong("localGeneration", 0L));
                    recoveryNotice = "The local database could not be opened, so Account Path kept the old database file aside and restored the latest on-device recovery snapshot. Please export a JSON backup now and check both profiles.";
                } else {
                    recoveryNotice = "The local database could not be opened. A fresh database was created, but no automatic recovery snapshot was available. Use Import / Restore in Trade Log if you have a JSON backup.";
                }
            } catch (Exception secondError) {
                storageFailure = "Local storage could not be opened. Do not clear Account Path's app data. Try restarting the app. If this persists, reinstalling may not preserve unsaved data; restore from an exported JSON backup.";
                db = null;
            }
        }
        if (db == null) return;
        try {
            long dbGeneration = db.getGeneration();
            if (recovery != null) {
                long recoveryGeneration = recovery.optLong("localGeneration", -1L);
                if (recoveryGeneration > dbGeneration) {
                    List<ProfileData> profiles = BackupCodec.parseAll(recovery);
                    db.replaceAllProfiles(profiles, recoveryGeneration);
                    recoveryNotice = "A newer complete on-device recovery snapshot was found and restored. Review both profiles and export an external JSON backup.";
                }
            }
            writeRecoverySnapshot();
        } catch (Exception ex) {
            recoveryNotice = "Account Path opened its local database, but its automatic recovery snapshot needs attention. Export a JSON backup after checking your balances.";
        }
    }

    private boolean quarantineDatabaseFiles() {
        File base = getDatabasePath("account_path_local.db");
        boolean allOkay = true;
        for (String suffix : new String[]{"", "-wal", "-shm", "-journal"}) {
            File f = new File(base.getPath() + suffix);
            if (!f.exists()) continue;
            File saved = new File(f.getPath() + ".unreadable-" + System.currentTimeMillis());
            if (!f.renameTo(saved)) allOkay = false;
        }
        return allOkay;
    }

    private JSONObject readBestRecoveryRoot() {
        File latest = new File(getFilesDir(), "account_path_recovery.json");
        File previous = new File(getFilesDir(), "account_path_recovery.previous.json");
        JSONObject a = readJsonFile(latest), b = readJsonFile(previous);
        if (!isValidRecoveryRoot(a)) a = null;
        if (!isValidRecoveryRoot(b)) b = null;
        if (a == null) return b;
        if (b == null) return a;
        long ga = a.optLong("localGeneration", -1L), gb = b.optLong("localGeneration", -1L);
        if (ga != gb) return ga > gb ? a : b;
        return a.optString("exportedAt", "").compareTo(b.optString("exportedAt", "")) >= 0 ? a : b;
    }

    private JSONObject readJsonFile(File file) {
        if (file == null || !file.isFile()) return null;
        try (InputStream in = new FileInputStream(file)) { return new JSONObject(new String(readFully(in), StandardCharsets.UTF_8)); }
        catch (Exception ex) { return null; }
    }

    private boolean isValidRecoveryRoot(JSONObject root) {
        if (root == null) return false;
        try { BackupCodec.parseAll(root); return true; }
        catch (Exception ex) { return false; }
    }

    private void writeRecoverySnapshot() {
        if (db == null) return;
        File dir = getFilesDir();
        File temp = new File(dir, "account_path_recovery.tmp");
        File latest = new File(dir, "account_path_recovery.json");
        File previous = new File(dir, "account_path_recovery.previous.json");
        try {
            JSONObject root = BackupCodec.exportRoot(db.getAllProfiles(), db.getGeneration(), activeProfile, activeTab);
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
                out.flush(); out.getFD().sync();
            }
            if (latest.exists()) {
                if (previous.exists() && !previous.delete()) throw new java.io.IOException("Could not rotate recovery snapshot.");
                if (!latest.renameTo(previous)) { copyFile(latest, previous); if (!latest.delete()) throw new java.io.IOException("Could not rotate the recovery snapshot safely."); }
            }
            if (!temp.renameTo(latest)) {
                copyFile(temp, latest);
                if (!temp.delete()) temp.deleteOnExit();
            }
        } catch (Exception ex) {
            // Database transactions remain authoritative. The UI asks for a manual export when this happens.
            statusMessage = "Automatic recovery snapshot failed. Please export a JSON backup.";
            statusIsError = true;
        }
    }

    private static void copyFile(File from, File to) throws java.io.IOException {
        try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) >= 0) if (count > 0) out.write(buffer, 0, count);
            out.flush();
        }
    }

    private static byte[] readFully(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int n;
        while ((n = in.read(buffer)) >= 0) if (n > 0) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private void buildScaffold() {
        outer = new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL); outer.setBackgroundColor(BG);
        outer.setPadding(dp(16), dp(12), dp(16), dp(8));
        setContentView(outer);

        LinearLayout heading = row(); heading.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout branding = column();
        branding.addView(text("ACCOUNT PATH", 21, TEXT, true));
        branding.addView(text("LOCAL-FIRST  ·  OFFLINE  ·  PRIVATE", 10, MUTED, true));
        heading.addView(branding, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView version = text("v1", 11, MINT, true); version.setBackground(round(CARD_ALT, dp(12), MINT, dp(1))); version.setPadding(dp(10), dp(5), dp(10), dp(5));
        heading.addView(version);
        outer.addView(heading);
        addGap(outer, 13);

        profileButtons = row();
        slowProfileButton = profileButton("◈  Slow Growth", "slow");
        playProfileButton = profileButton("✦  Play Money", "play");
        profileButtons.addView(slowProfileButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        addGapHorizontal(profileButtons, 8);
        profileButtons.addView(playProfileButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        outer.addView(profileButtons);
        addGap(outer, 10);

        LinearLayout balanceCard = card(); balanceCard.setPadding(dp(17), dp(15), dp(17), dp(15));
        LinearLayout balanceTop = row(); balanceTop.setGravity(Gravity.CENTER_VERTICAL);
        balanceTitle = text("SLOW GROWTH · ACCOUNT TOTAL", 11, MUTED, true);
        balanceTop.addView(balanceTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        profileStatus = text("SETUP NEEDED", 10, AMBER, true); profileStatus.setPadding(dp(8), dp(4), dp(8), dp(4)); profileStatus.setBackground(round(Color.rgb(59, 46, 24), dp(10), Color.TRANSPARENT, 0));
        balanceTop.addView(profileStatus);
        balanceCard.addView(balanceTop);
        balanceValue = text("Not set", 30, TEXT, true); balanceValue.setPadding(0, dp(7), 0, dp(3)); balanceCard.addView(balanceValue);
        balanceSub = text("Set starting capital in Trade Log.", 12, MUTED, false); balanceCard.addView(balanceSub);
        outer.addView(balanceCard);
        addGap(outer, 11);

        HorizontalScrollView tabScroll = new HorizontalScrollView(this); tabScroll.setHorizontalScrollBarEnabled(false); tabScroll.setFillViewport(true);
        LinearLayout tabs = row(); tabs.setPadding(dp(3), dp(3), dp(3), dp(3)); tabs.setBackground(round(CARD, dp(15), Color.TRANSPARENT, 0));
        goalTabButton = tabButton("PROFIT GOAL", "goal");
        forecastTabButton = tabButton("FORECAST", "forecast");
        logTabButton = tabButton("TRADE LOG", "log");
        tabs.addView(goalTabButton, new LinearLayout.LayoutParams(0, dp(42), 1f));
        tabs.addView(forecastTabButton, new LinearLayout.LayoutParams(0, dp(42), 1f));
        tabs.addView(logTabButton, new LinearLayout.LayoutParams(0, dp(42), 1f));
        tabScroll.addView(tabs); outer.addView(tabScroll);
        addGap(outer, 7);

        messageView = text("", 12, MUTED, false); messageView.setPadding(dp(11), dp(8), dp(11), dp(8)); messageView.setVisibility(View.GONE);
        messageView.setBackground(round(CARD_ALT, dp(10), Color.TRANSPARENT, 0)); outer.addView(messageView);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false); scroll.setVerticalScrollBarEnabled(false);
        content = column(); content.setPadding(0, dp(5), 0, dp(22));
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private TextView profileButton(String label, String id) {
        TextView b = text(label, 13, TEXT, true); b.setGravity(Gravity.CENTER); b.setPadding(dp(7), 0, dp(7), 0);
        b.setBackground(round(CARD, dp(13), LINE, dp(1)));
        b.setOnClickListener(v -> {
            activeProfile = id; preferences.edit().putString("activeProfile", id).apply();
            expandedWeeks.clear(); statusMessage = ""; statusIsError = false; refreshAll();
        });
        return b;
    }

    private LinearLayout tabButton(String label, String id) {
        LinearLayout tab = new LinearLayout(this); tab.setGravity(Gravity.CENTER); tab.setOrientation(LinearLayout.VERTICAL); tab.setBackground(round(CARD, dp(12), Color.TRANSPARENT, 0));
        TextView labelView = text(label, 11, MUTED, true); labelView.setGravity(Gravity.CENTER); tab.addView(labelView);
        tab.setOnClickListener(v -> { activeTab = id; preferences.edit().putString("activeTab", id).apply(); statusMessage = ""; statusIsError = false; refreshAll(); });
        return tab;
    }

    private void refreshAll() {
        if (db == null) {
            if (content != null) {
                content.removeAllViews();
                addCardMessage(content, "Storage unavailable", storageFailure.isEmpty() ? "Restart the app. Do not clear app data. Restore from a JSON backup if available." : storageFailure, RED);
                Button restore = actionButton("Import full JSON backup", MINT, BG);
                content.addView(restore, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
                restore.setOnClickListener(v -> startRestore());
                addGap(content, 8);
                Button retry = actionButton("Try opening local storage again", CARD_ALT, TEXT);
                content.addView(retry, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(45)));
                retry.setOnClickListener(v -> { storageFailure = ""; initializeStorage(); refreshAll(); });
            }
            if (balanceValue != null) balanceValue.setText("Unavailable");
            if (messageView != null && !storageFailure.isEmpty()) showMessage(storageFailure, true);
            return;
        }
        ProfileData p = db.getProfile(activeProfile);
        AccountSnapshot d = AccountEngine.calculate(p);
        balanceTitle.setText(profileName(activeProfile).toUpperCase(Locale.ROOT) + " · ACCOUNT TOTAL");
        balanceValue.setText(d.isSet ? money(d.balance, p) : "Not set");
        balanceSub.setText(d.isSet ? "Live total · includes manual plus / minus" : "Enter starting capital once in Trade Log.");
        profileStatus.setText(!d.isSet ? "SETUP NEEDED" : d.error != null ? "CHECK HISTORY" : d.balance <= EPSILON ? "ZERO BALANCE" : (d.wins + d.losses) + " OUTCOMES");
        int statusColor = !d.isSet ? AMBER : d.error != null || d.balance <= EPSILON ? RED : MINT;
        profileStatus.setTextColor(statusColor);
        profileStatus.setBackground(round(statusColor == AMBER ? Color.rgb(59,46,24) : statusColor == RED ? Color.rgb(64,31,44) : Color.rgb(20,55,56), dp(10), Color.TRANSPARENT, 0));
        slowProfileButton.setTextColor("slow".equals(activeProfile) ? MINT : TEXT);
        slowProfileButton.setBackground(round("slow".equals(activeProfile) ? Color.rgb(19, 45, 57) : CARD, dp(13), "slow".equals(activeProfile) ? MINT : LINE, dp(1)));
        playProfileButton.setTextColor("play".equals(activeProfile) ? MINT : TEXT);
        playProfileButton.setBackground(round("play".equals(activeProfile) ? Color.rgb(19, 45, 57) : CARD, dp(13), "play".equals(activeProfile) ? MINT : LINE, dp(1)));
        styleTab(goalTabButton, "goal"); styleTab(forecastTabButton, "forecast"); styleTab(logTabButton, "log");
        if (messageView != null) {
            if (statusMessage.isEmpty()) messageView.setVisibility(View.GONE);
            else { messageView.setVisibility(View.VISIBLE); messageView.setText(statusMessage); messageView.setTextColor(statusIsError ? RED : MINT); }
        }
        content.removeAllViews();
        if ("goal".equals(activeTab)) renderGoal(p, d);
        else if ("forecast".equals(activeTab)) renderForecast(p, d);
        else renderLog(p, d);
    }

    private void styleTab(LinearLayout button, String id) {
        boolean selected = activeTab.equals(id);
        button.setBackground(round(selected ? Color.rgb(19, 45, 57) : CARD, dp(12), selected ? MINT : Color.TRANSPARENT, selected ? dp(1) : 0));
        if (button.getChildCount() > 0 && button.getChildAt(0) instanceof TextView) ((TextView) button.getChildAt(0)).setTextColor(selected ? MINT : MUTED);
    }

    private void renderGoal(ProfileData p, AccountSnapshot d) {
        addSectionTitle(content, "Profit goal", "Enter the amount of profit you want to make.");
        if (!d.isSet) {
            addCardMessage(content, "One-time setup", "Open Trade Log and enter your own starting capital. Once saved, the setup field locks until you press Blown Account.", AMBER);
            return;
        }
        LinearLayout c = card();
        c.addView(text("PROFIT TARGET", 10, MUTED, true));
        EditText amount = editText("e.g. 100", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amount.setText(p.targetProfit == null ? "" : p.targetProfit);
        amount.setHint("Profit amount");
        amount.setTextSize(21); amount.setPadding(dp(13), dp(11), dp(13), dp(11));
        LinearLayout.LayoutParams inp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)); inp.topMargin = dp(8); inp.bottomMargin = dp(11); c.addView(amount, inp);
        Button calc = actionButton("Calculate dates", MINT, BG);
        c.addView(calc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        calc.setOnClickListener(v -> {
            double goal = parseAmount(amount.getText().toString());
            if (!Double.isFinite(goal) || goal <= 0) { showMessage("Enter a profit target greater than zero.", true); return; }
            try { db.setTargetProfit(activeProfile, Double.toString(goal)); afterDataChange(); showMessage("Profit target saved for " + profileName(activeProfile) + ".", false); }
            catch (Exception ex) { showMessage(messageOf(ex), true); }
        });
        content.addView(c);

        double goal = parseAmount(p.targetProfit);
        if (!Double.isFinite(goal) || goal <= 0) {
            addCardMessage(content, "Ready when you are", "The calculator estimates dates from this profile's own recorded wins, losses and dated trading pace. Manual balance adjustments do not train it.", MUTED);
            return;
        }
        addGap(content, 10);
        LinearLayout progress = card();
        addRowStat(progress, "TARGET PROFIT", money(goal, p), MINT);
        addRowStat(progress, "TRADING-ONLY NET", signedMoney(d.netTrading, p), d.netTrading >= 0 ? GREEN : RED);
        double left = Math.max(0, goal - d.netTrading);
        addRowStat(progress, d.netTrading >= goal ? "STATUS" : "NET PROFIT LEFT", d.netTrading >= goal ? "Goal reached" : money(left, p), d.netTrading >= goal ? GREEN : AMBER);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000); bar.setProgress((int) Math.round(Math.max(0, Math.min(1, d.netTrading / goal)) * 1000));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(LINE));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)); bp.topMargin = dp(4); bp.bottomMargin = dp(5); progress.addView(bar, bp);
        progress.addView(text(String.format(Locale.ENGLISH, "%.1f%% of target by net wins/losses", Math.max(0, Math.min(100, d.netTrading / goal * 100))), 11, MUTED, false));
        content.addView(progress);
        addGap(content, 10);
        addSectionTitle(content, "When might you reach it?", "Scenario dates, not promises.");
        if (d.netTrading >= goal) {
            LinearLayout reached = card(); reached.addView(text("GOAL REACHED", 19, GREEN, true)); reached.addView(text("Your recorded win/loss result has met this profit target. Manual plus/minus changes are excluded.", 12, MUTED, false)); content.addView(reached);
        } else {
            ForecastEngine.Estimate estimate = ForecastEngine.estimate(p, d, d.initialCapital + goal);
            if (!estimate.ready) {
                addCardMessage(content, "Collecting your history", estimate.reason + " Your records continue saving normally; no date is invented while the sample is too small.", AMBER);
            } else {
                LinearLayout dates = card();
                addEstimateRow(dates, "EARLIER PATH", estimate.earlierDate, estimate.earlierDetail, GREEN);
                addDivider(dates);
                addEstimateRow(dates, "TYPICAL PATH", estimate.typicalDate, estimate.typicalDetail, MINT);
                addDivider(dates);
                addEstimateRow(dates, "SLOWER PATH", estimate.slowerDate, estimate.slowerDetail, AMBER);
                content.addView(dates);
                addGap(content, 6);
                content.addView(text("Based on this profile's recorded percentage outcomes and actual calendar pace. Future conditions can differ; extreme observed returns are limited in the simulation only.", 11, MUTED, false));
            }
        }
    }

    private void renderForecast(ProfileData p, AccountSnapshot d) {
        addSectionTitle(content, "Forecast & statistics", "Only this profile's wins and losses train its model.");
        ForecastEngine.Stats s = ForecastEngine.stats(p, d);
        ForecastEngine.Cadence cadence = ForecastEngine.cadence(d);
        LinearLayout stats = card();
        addStatGrid(stats, "OUTCOMES", Integer.toString(s.outcomes), s.outcomes >= ForecastEngine.MIN_OUTCOMES ? MINT : TEXT,
                "WIN RATE", percent(s.winRate), TEXT);
        addDivider(stats);
        addStatGrid(stats, "AVERAGE WIN", Double.isFinite(s.averageWin) ? money(s.averageWin, p) : "—", GREEN,
                "AVERAGE LOSS", Double.isFinite(s.averageLoss) ? money(s.averageLoss, p) : "—", RED);
        addDivider(stats);
        addStatGrid(stats, "WIN / LOSS SIZE", Double.isFinite(s.payoff) ? String.format(Locale.ENGLISH, "%.2f×", s.payoff) : "—", TEXT,
                "NET TRADING RESULT", signedMoney(d.netTrading, p), d.netTrading >= 0 ? GREEN : RED);
        addDivider(stats);
        addStatGrid(stats, "AVERAGE PER OUTCOME", Double.isFinite(s.expectancy) ? signedMoney(s.expectancy, p) : "—", Double.isFinite(s.expectancy) && s.expectancy < 0 ? RED : GREEN,
                "RESULT VARIABILITY", Double.isFinite(s.simpleReturnSd) ? percent(s.simpleReturnSd) : "—", TEXT);
        addDivider(stats);
        String weeksValue = s.totalWeeks == 0 ? "—" : (s.positiveWeeks + " positive · " + s.negativeWeeks + " negative");
        addStatGrid(stats, "WEEKLY NET", weeksValue, TEXT,
                "CONSISTENCY", s.consistency, TEXT);
        addDivider(stats);
        addStatGrid(stats, "LARGEST WIN / LOSS", (Double.isFinite(s.largestWin) ? money(s.largestWin, p) : "—") + " / " + (Double.isFinite(s.largestLoss) ? money(s.largestLoss, p) : "—"), TEXT,
                "BEST STREAK", s.bestWinStreak + " wins · " + s.bestLossStreak + " losses", TEXT);
        addDivider(stats);
        addStatGrid(stats, "CURRENT STREAK", s.currentStreak == 0 ? "—" : s.currentStreak + " " + ("win".equals(s.currentStreakKind) ? "wins" : "losses"), TEXT,
                "RECORDED EVENTS", Integer.toString(d.sortedEvents.size()), TEXT);
        content.addView(stats);

        addGap(content, 10);
        LinearLayout pace = card();
        pace.addView(text("OBSERVED TRADING PACE", 11, MUTED, true));
        if (cadence.ready) {
            pace.addView(text(String.format(Locale.ENGLISH, "%.1f win/loss outcomes per calendar week", cadence.tradesPerWeek), 18, MINT, true));
            pace.addView(text("From " + formatDate(cadence.firstDate, false) + " to " + formatDate(cadence.lastDate, false) + " · " + cadence.records + " outcomes across " + cadence.spanDays + " days. Weekends and gaps are included.", 11, MUTED, false));
        } else {
            pace.addView(text(cadence.reason, 12, MUTED, false));
        }
        content.addView(pace);

        addGap(content, 12);
        addSectionTitle(content, "Growth tiers", "Target amounts are multiples of your own starting capital.");
        if (!d.isSet) {
            addCardMessage(content, "Setup needed", "Enter starting capital in Trade Log. Nothing is assumed for either profile.", AMBER);
            return;
        }
        int[] multipliers = {25, 175, 875, 5000};
        String[] names = {"TIER 1", "TIER 2", "TIER 3", "TIER 4"};
        double[] targets = new double[multipliers.length];
        for (int i = 0; i < multipliers.length; i++) targets[i] = d.initialCapital * multipliers[i];
        List<ForecastEngine.Estimate> estimates = ForecastEngine.estimateMany(p, d, targets);
        for (int i = 0; i < multipliers.length; i++) {
            LinearLayout tier = card();
            LinearLayout top = row(); top.setGravity(Gravity.CENTER_VERTICAL);
            top.addView(text(names[i], 11, MINT, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            top.addView(text(multipliers[i] + "× start", 11, MUTED, true)); tier.addView(top);
            tier.addView(text(money(targets[i], p), 24, TEXT, true));
            double current = d.modelBalance <= 0 ? 0 : Math.max(0, Math.min(100, d.modelBalance / targets[i] * 100));
            tier.addView(text(String.format(Locale.ENGLISH, "%.2f%% along the trading-only path", current), 11, MUTED, false));
            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(1000); bar.setProgress((int) Math.round(current * 10)); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT)); bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(LINE));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)); bp.topMargin = dp(5); bp.bottomMargin = dp(8); tier.addView(bar, bp);
            ForecastEngine.Estimate e = estimates.get(i);
            if (!e.ready) {
                tier.addView(text(e.reason, 12, AMBER, false));
            } else if (e.alreadyReached) {
                tier.addView(text("Already reached on the trading-only path", 12, GREEN, true));
            } else {
                addEstimateRow(tier, "EARLIER", e.earlierDate, e.earlierDetail, GREEN);
                addDivider(tier);
                addEstimateRow(tier, "TYPICAL", e.typicalDate, e.typicalDetail, MINT);
                addDivider(tier);
                addEstimateRow(tier, "SLOWER", e.slowerDate, e.slowerDetail, AMBER);
            }
            content.addView(tier); addGap(content, 8);
        }
        addCardMessage(content, "How to read this", "These are bootstrapped scenarios, not promises. The model requires 20+ win/loss outcomes, enough variation, at least three distinct outcome dates spanning 14 calendar days, and uses only this profile. Manual additions/subtractions are excluded. The simulation is capped at 1,000 future outcomes.", MUTED);
    }

    private void renderLog(ProfileData p, AccountSnapshot d) {
        addSectionTitle(content, "Trade Log", "All account events are recorded here.");
        if (!d.isSet) {
            LinearLayout setup = card();
            setup.addView(text("STARTING CAPITAL", 11, MUTED, true));
            setup.addView(text("Enter the starting amount for " + profileName(activeProfile) + ". It is recorded once and then locked.", 12, TEXT, false));
            EditText capital = editText("Starting amount", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            capital.setTextSize(22); capital.setPadding(dp(13), dp(10), dp(13), dp(10));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)); ip.topMargin = dp(10); ip.bottomMargin = dp(8); setup.addView(capital, ip);
            EditText currency = editText("Currency symbol (e.g. €)", InputType.TYPE_CLASS_TEXT);
            currency.setText(p.currency == null ? "€" : p.currency); currency.setSingleLine(true); currency.setPadding(dp(13), dp(8), dp(13), dp(8));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)); cp.bottomMargin = dp(10); setup.addView(currency, cp);
            Button save = actionButton("Lock starting capital", MINT, BG); setup.addView(save, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
            save.setOnClickListener(v -> {
                double value = parseAmount(capital.getText().toString());
                if (!Double.isFinite(value) || value <= 0) { showMessage("Enter a starting amount greater than zero.", true); return; }
                try { db.setStartingCapital(activeProfile, value, currency.getText().toString()); afterDataChange(); showMessage("Starting capital saved and locked for this cycle.", false); refreshAll(); }
                catch (Exception ex) { showMessage(messageOf(ex), true); }
            });
            content.addView(setup);
            if (!p.events.isEmpty()) {
                addGap(content, 8);
                addCardMessage(content, "Recovered event history", "This profile has saved events but no starting capital. Enter the starting amount needed to recalculate the account total.", AMBER);
            }
            addGap(content, 10);
            renderHistory(p, d);
            renderBackupControls(p, d);
            return;
        }

        LinearLayout entry = card();
        LinearLayout dateRow = row(); dateRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout dateText = column(); dateText.addView(text("ENTRY DATE", 10, MUTED, true));
        TextView dateValue = text(formatDate(selectedDate.toString(), true), 14, TEXT, true); dateValue.setPadding(0, dp(4), 0, 0); dateText.addView(dateValue);
        dateRow.addView(dateText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button chooseDate = smallButton("Change date", CARD_ALT, TEXT); dateRow.addView(chooseDate);
        chooseDate.setOnClickListener(v -> new DatePickerDialog(this, (view, year, month, day) -> {
            selectedDate = LocalDate.of(year, month + 1, day); refreshAll();
        }, selectedDate.getYear(), selectedDate.getMonthValue() - 1, selectedDate.getDayOfMonth()).show());
        entry.addView(dateRow);
        addGap(entry, 13);
        entry.addView(text("WIN / LOSS", 10, MUTED, true));
        EditText tradeAmount = editText("Amount won or lost", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        tradeAmount.setTextSize(22); tradeAmount.setPadding(dp(13), dp(10), dp(13), dp(10));
        LinearLayout.LayoutParams tap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)); tap.topMargin = dp(6); tap.bottomMargin = dp(9); entry.addView(tradeAmount, tap);
        LinearLayout tradeButtons = row();
        Button win = actionButton("✓  WIN", Color.rgb(15, 80, 63), GREEN);
        Button loss = actionButton("−  LOSS", Color.rgb(78, 35, 49), RED);
        tradeButtons.addView(win, new LinearLayout.LayoutParams(0, dp(48), 1f)); addGapHorizontal(tradeButtons, 9); tradeButtons.addView(loss, new LinearLayout.LayoutParams(0, dp(48), 1f));
        entry.addView(tradeButtons);
        win.setOnClickListener(v -> handleEntry("win", tradeAmount.getText().toString(), selectedDate.toString()));
        loss.setOnClickListener(v -> handleEntry("loss", tradeAmount.getText().toString(), selectedDate.toString()));
        addDivider(entry);
        entry.addView(text("MANUAL BALANCE CONTROL", 10, MUTED, true));
        entry.addView(text("These buttons change the total but never train the forecast.", 11, MUTED, false));
        EditText adjustAmount = editText("Manual amount", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        adjustAmount.setPadding(dp(13), dp(9), dp(13), dp(9));
        LinearLayout.LayoutParams aap = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)); aap.topMargin = dp(7); aap.bottomMargin = dp(8); entry.addView(adjustAmount, aap);
        LinearLayout manualButtons = row();
        Button plus = actionButton("＋  ADD", Color.rgb(20, 55, 56), MINT);
        Button minus = actionButton("−  SUBTRACT", CARD_ALT, TEXT);
        manualButtons.addView(plus, new LinearLayout.LayoutParams(0, dp(45), 1f)); addGapHorizontal(manualButtons, 9); manualButtons.addView(minus, new LinearLayout.LayoutParams(0, dp(45), 1f));
        entry.addView(manualButtons);
        plus.setOnClickListener(v -> handleEntry("add", adjustAmount.getText().toString(), selectedDate.toString()));
        minus.setOnClickListener(v -> handleEntry("subtract", adjustAmount.getText().toString(), selectedDate.toString()));
        content.addView(entry);

        addGap(content, 10);
        addSectionTitle(content, "Recorded stats", "Descriptive only; manual adjustments are separated.");
        LinearLayout statCard = card();
        ForecastEngine.Stats s = ForecastEngine.stats(p, d);
        addStatGrid(statCard, "WINS / LOSSES", s.wins + " / " + s.losses, TEXT,
                "WIN RATE", percent(s.winRate), TEXT);
        addDivider(statCard);
        addStatGrid(statCard, "NET FROM TRADES", signedMoney(d.netTrading, p), d.netTrading >= 0 ? GREEN : RED,
                "MANUAL NET", signedMoney(d.netManual, p), d.netManual >= 0 ? MINT : RED);
        addDivider(statCard);
        addStatGrid(statCard, "AVERAGE WIN / LOSS", (Double.isFinite(s.averageWin) ? money(s.averageWin, p) : "—") + " / " + (Double.isFinite(s.averageLoss) ? money(s.averageLoss, p) : "—"), TEXT,
                "LARGEST WIN / LOSS", (Double.isFinite(s.largestWin) ? money(s.largestWin, p) : "—") + " / " + (Double.isFinite(s.largestLoss) ? money(s.largestLoss, p) : "—"), TEXT);
        addDivider(statCard);
        addStatGrid(statCard, "POSITIVE / NEGATIVE WEEKS", s.totalWeeks == 0 ? "—" : s.positiveWeeks + " / " + s.negativeWeeks, TEXT,
                "BEST STREAK", s.bestWinStreak + " wins · " + s.bestLossStreak + " losses", TEXT);
        content.addView(statCard);
        addGap(content, 10);
        renderHistory(p, d);
        renderBackupControls(p, d);
    }

    private void handleEntry(String kind, String amountText, String date) {
        if (db == null) return;
        double amount = parseAmount(amountText);
        if (!Double.isFinite(amount) || amount <= 0) { showMessage("Enter an amount greater than zero.", true); return; }
        ProfileData p = db.getProfile(activeProfile); AccountSnapshot d = AccountEngine.calculate(p);
        if (!d.isSet) { showMessage("Set starting capital first.", true); return; }
        if (d.error != null) { showMessage(d.error, true); return; }
        if (d.balance <= EPSILON) { showMessage("The account total is zero. Use Blown Account to clear this profile's cycle before recording further entries.", true); return; }
        if (("loss".equals(kind) || "subtract".equals(kind)) && amount > d.balance + EPSILON) {
            showMessage("That amount is larger than the current account total. Nothing was recorded.", true); return;
        }
        if ("subtract".equals(kind) && amount >= d.balance - EPSILON) {
            new AlertDialog.Builder(this).setTitle("Manual subtraction empties account")
                    .setMessage("This manual subtraction would empty " + profileName(activeProfile) + ". The Blown Account action clears this profile's entire history and learned model, then asks for new starting capital. Continue and start a fresh cycle? The other profile will not be touched.")
                    .setNegativeButton("Cancel", (dialog, which) -> showMessage("No change made.", false))
                    .setPositiveButton("Blown Account", (dialog, which) -> {
                        try { db.resetCycle(activeProfile); afterDataChange(); selectedDate = LocalDate.now(); expandedWeeks.clear(); showMessage("Profile cleared. Enter starting capital to begin again.", false); refreshAll(); }
                        catch (Exception ex) { showMessage(messageOf(ex), true); }
                    }).show();
            return;
        }
        try {
            TradeEvent event = new TradeEvent(UUID.randomUUID().toString(), date, kind, amount, System.currentTimeMillis());
            db.addEvent(activeProfile, event);
            afterDataChange();
            AccountSnapshot updated = AccountEngine.calculate(db.getProfile(activeProfile));
            if ("loss".equals(kind) && updated.isSet && updated.balance <= EPSILON) {
                showMessage("Loss recorded. The account total is now zero; press Blown Account when you are ready to start a new cycle.", true);
            } else {
                showMessage(eventLabel(kind) + " recorded for " + profileName(activeProfile) + ".", false);
            }
            refreshAll();
        } catch (Exception ex) { showMessage(messageOf(ex), true); }
    }

    private void renderHistory(ProfileData p, AccountSnapshot d) {
        addSectionTitle(content, "Trade history", "Grouped by year, month and week · tap a week to expand.");
        if (p.events.isEmpty()) {
            addCardMessage(content, "Nothing recorded yet", "Your wins, losses and manual balance changes will appear here, grouped by date.", MUTED);
            return;
        }
        List<TradeEvent> rev = new ArrayList<>(d.sortedEvents); Collections.reverse(rev);
        List<WeekBucket> weeks = new ArrayList<>();
        Map<String, WeekBucket> byKey = new LinkedHashMap<>();
        for (TradeEvent e : rev) {
            LocalDate date;
            try { date = LocalDate.parse(e.date); } catch (RuntimeException ex) { continue; }
            int weekNo = (date.getDayOfMonth() - 1) / 7 + 1;
            String key = String.format(Locale.ROOT, "%04d-%02d-W%d", date.getYear(), date.getMonthValue(), weekNo);
            WeekBucket b = byKey.get(key);
            if (b == null) {
                int start = (weekNo - 1) * 7 + 1;
                int end = Math.min(weekNo * 7, date.lengthOfMonth());
                b = new WeekBucket(key, date.getYear(), date.getMonthValue(), weekNo,
                        "Week " + weekNo + " · " + start + "–" + end + " " + date.getMonth().getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH));
                byKey.put(key, b); weeks.add(b);
            }
            b.events.add(e);
        }
        if (expandedWeeks.isEmpty() && !weeks.isEmpty()) expandedWeeks.add(weeks.get(0).key);
        int lastYear = -1, lastMonth = -1;
        for (WeekBucket b : weeks) {
            if (b.year != lastYear) {
                TextView year = text(Integer.toString(b.year), 16, MINT, true); year.setPadding(dp(2), dp(7), 0, dp(4)); content.addView(year); lastYear = b.year; lastMonth = -1;
            }
            if (b.month != lastMonth) {
                TextView month = text(LocalDate.of(b.year, b.month, 1).getMonth().getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH), 13, TEXT, true);
                month.setPadding(dp(2), dp(7), 0, dp(5)); content.addView(month); lastMonth = b.month;
            }
            LinearLayout weekCard = column(); weekCard.setBackground(round(CARD, dp(13), LINE, dp(1))); weekCard.setPadding(dp(12), dp(4), dp(12), dp(7));
            LinearLayout weekHead = row(); weekHead.setGravity(Gravity.CENTER_VERTICAL); weekHead.setPadding(0, dp(6), 0, dp(6));
            TextView weekLabel = text(b.label, 12, TEXT, true); weekHead.addView(weekLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView count = text(b.events.size() + (b.events.size() == 1 ? " entry" : " entries") + (expandedWeeks.contains(b.key) ? "  ▾" : "  ▸"), 10, MUTED, true); weekHead.addView(count);
            weekCard.addView(weekHead);
            weekHead.setOnClickListener(v -> {
                if (expandedWeeks.contains(b.key)) expandedWeeks.remove(b.key); else expandedWeeks.add(b.key);
                renderCurrentPanel();
            });
            if (expandedWeeks.contains(b.key)) {
                for (TradeEvent e : b.events) {
                    addDivider(weekCard);
                    weekCard.addView(renderEventRow(e, d, p));
                }
            }
            content.addView(weekCard); addGap(content, 7);
        }
        if (d.error != null) addCardMessage(content, "History needs attention", d.error, RED);
    }

    private View renderEventRow(TradeEvent e, AccountSnapshot d, ProfileData p) {
        LinearLayout row = row(); row.setPadding(0, dp(8), 0, dp(8)); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = column(); left.setPadding(0, 0, dp(5), 0);
        TextView kind = text(eventLabel(e.kind), 10, eventColor(e.kind), true); left.addView(kind);
        TextView date = text(formatDate(e.date, true), 10, MUTED, false); date.setPadding(0, dp(2), 0, dp(3)); left.addView(date);
        Double after = d.balanceAfterByEvent.get(e.id);
        String amount = (("win".equals(e.kind) || "add".equals(e.kind)) ? "+" : "−") + money(e.amount, p);
        TextView amountView = text(amount, 14, eventColor(e.kind), true); left.addView(amountView);
        String note = "Account after: " + (after == null ? "—" : money(after, p));
        if ("add".equals(e.kind) || "subtract".equals(e.kind)) note += " · not used for forecast";
        TextView sub = text(note, 10, MUTED, false); sub.setPadding(0, dp(2), 0, 0); left.addView(sub);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button remove = smallButton("×", Color.rgb(64, 31, 44), RED); remove.setMinWidth(dp(38));
        remove.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete entry?")
                .setMessage("This recalculates the account total and statistics from the remaining events. The action cannot be undone unless you restore a backup.")
                .setNegativeButton("Cancel", null).setPositiveButton("Delete", (dialog, which) -> {
                    try { db.deleteEvent(activeProfile, e.id); afterDataChange(); showMessage("Entry deleted and history recalculated.", false); refreshAll(); }
                    catch (Exception ex) { showMessage(messageOf(ex), true); }
                }).show());
        row.addView(remove);
        return row;
    }

    private void renderBackupControls(ProfileData p, AccountSnapshot d) {
        addGap(content, 13);
        addSectionTitle(content, "Backups & account control", "The app also keeps two automatic recovery snapshots privately on this phone.");
        LinearLayout card = card();
        Button export = actionButton("⇩  Export JSON backup", MINT, BG);
        card.addView(export, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(47)));
        export.setOnClickListener(v -> startExport());
        addGap(card, 8);
        Button restore = actionButton("Import / restore full backup", CARD_ALT, TEXT);
        card.addView(restore, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(45)));
        restore.setOnClickListener(v -> startRestore());
        addGap(card, 8);
        Button rebuild = actionButton("⟳  Rebuild this profile from backups", CARD_ALT, TEXT);
        card.addView(rebuild, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(45)));
        rebuild.setOnClickListener(v -> startRebuild());
        addGap(card, 12); addDivider(card); addGap(card, 6);
        TextView info = text("PROFILE RESET", 10, MUTED, true); card.addView(info);
        TextView details = text("Blown Account deletes this profile's starting amount, events and learned model. The other profile is untouched.", 11, MUTED, false); details.setPadding(0, dp(4), 0, dp(8)); card.addView(details);
        Button blown = actionButton("Blown Account", Color.rgb(78, 35, 49), RED);
        card.addView(blown, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        blown.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Blown Account · " + profileName(activeProfile))
                .setMessage("This permanently clears the selected profile's starting capital, all wins/losses, manual changes, history and learned forecast. You will enter starting capital again. The other profile will not change.")
                .setNegativeButton("Cancel", null).setPositiveButton("Clear this profile", (dialog, which) -> {
                    try { db.resetCycle(activeProfile); afterDataChange(); expandedWeeks.clear(); selectedDate = LocalDate.now(); showMessage(profileName(activeProfile) + " cleared. Enter new starting capital to begin again.", false); refreshAll(); }
                    catch (Exception ex) { showMessage(messageOf(ex), true); }
                }).show());
        content.addView(card);
        addGap(content, 10);
        content.addView(text("Important: local data stays on this device and survives app restarts and app updates. Uninstalling the app or clearing its storage deletes local data. Keep exported JSON backups somewhere separate.", 11, MUTED, false));
    }

    private void startExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "account-path-backup-" + LocalDate.now() + ".json");
        try { startActivityForResult(intent, REQ_EXPORT); }
        catch (Exception ex) { showMessage("Could not open the file picker. " + messageOf(ex), true); }
    }

    private void startRestore() {
        new AlertDialog.Builder(this).setTitle("Restore full backup?")
                .setMessage("Choose a previous Account Path JSON backup. Restoring replaces both current profiles with the saved profiles. Export the current data first if you want to keep it.")
                .setNegativeButton("Cancel", null).setPositiveButton("Choose file", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
                    try { startActivityForResult(intent, REQ_RESTORE); } catch (Exception ex) { showMessage("Could not open the file picker. " + messageOf(ex), true); }
                }).show();
    }

    private void startRebuild() {
        new AlertDialog.Builder(this).setTitle("Rebuild " + profileName(activeProfile))
                .setMessage("Select as many JSON backups as you have. The app will merge unique events for this profile's current cycle. Only " + profileName(activeProfile) + " will change; the other profile stays untouched. The newest matching backup controls the starting setup.")
                .setNegativeButton("Cancel", null).setPositiveButton("Choose backups", (dialog, which) -> {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json"); intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    try { startActivityForResult(intent, REQ_REBUILD); } catch (Exception ex) { showMessage("Could not open the file picker. " + messageOf(ex), true); }
                }).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null && data.getClipData() == null) return;
        if (requestCode == REQ_EXPORT) { exportToUri(data.getData()); return; }
        if (requestCode == REQ_RESTORE) { restoreFromUri(data.getData()); return; }
        if (requestCode == REQ_REBUILD) { rebuildFromIntent(data); }
    }

    private void exportToUri(Uri uri) {
        if (uri == null || db == null) return;
        try {
            JSONObject root = BackupCodec.exportRoot(db.getAllProfiles(), db.getGeneration(), activeProfile, activeTab);
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new java.io.IOException("The chosen file could not be opened for writing.");
                out.write(root.toString(2).getBytes(StandardCharsets.UTF_8)); out.flush();
            }
            showMessage("JSON backup exported. Keep a copy outside the app.", false);
            Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) { showMessage("Backup export failed: " + messageOf(ex), true); }
    }

    private JSONObject readJsonUri(Uri uri) throws Exception {
        ContentResolver resolver = getContentResolver();
        try (InputStream in = resolver.openInputStream(uri)) {
            if (in == null) throw new java.io.IOException("The selected file could not be opened.");
            return new JSONObject(new String(readFully(in), StandardCharsets.UTF_8));
        }
    }

    private void restoreFromUri(Uri uri) {
        try {
            JSONObject root = readJsonUri(uri);
            List<ProfileData> imported = BackupCodec.parseAll(root);
            new AlertDialog.Builder(this).setTitle("Replace both profiles?")
                    .setMessage("The file passed validation. This replaces both profiles and their event history with the backup. Current profiles will be overwritten.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Restore backup", (dialog, which) -> {
                        try {
                            if (db == null) {
                                db = new AppDatabase(this);
                                db.getWritableDatabase();
                            }
                            db.replaceAllProfiles(imported, root.optLong("localGeneration", 0L));
                            storageFailure = "";
                            String targetProfile = root.optString("activeProfile", activeProfile);
                            if ("slow".equals(targetProfile) || "play".equals(targetProfile)) activeProfile = targetProfile;
                            preferences.edit().putString("activeProfile", activeProfile).apply();
                            afterDataChange(); expandedWeeks.clear(); showMessage("Both profiles restored successfully.", false); refreshAll();
                        } catch (Exception ex) { showMessage("Restore failed. Current data was not intentionally cleared: " + messageOf(ex), true); }
                    }).show();
        } catch (Exception ex) { showMessage("That file is not a valid Account Path backup: " + messageOf(ex), true); }
    }

    private static final class RebuildCandidate {
        String fileName;
        JSONObject root;
        JSONObject rawProfile;
        ProfileData profile;
        long stamp;
        String rawCycleId;
    }
    private static final class EventWithStamp {
        TradeEvent event;
        long stamp;
        EventWithStamp(TradeEvent event, long stamp) { this.event = event; this.stamp = stamp; }
    }

    private void rebuildFromIntent(Intent intent) {
        List<Uri> uris = new ArrayList<>();
        if (intent.getClipData() != null) {
            for (int i = 0; i < intent.getClipData().getItemCount(); i++) uris.add(intent.getClipData().getItemAt(i).getUri());
        } else if (intent.getData() != null) uris.add(intent.getData());
        if (uris.isEmpty()) { showMessage("No backup files selected.", true); return; }
        List<RebuildCandidate> parsed = new ArrayList<>(); List<String> errors = new ArrayList<>();
        for (int i = 0; i < uris.size(); i++) {
            Uri uri = uris.get(i);
            try {
                JSONObject root = readJsonUri(uri); JSONObject raw = BackupCodec.profileFromRoot(root, activeProfile);
                if (raw == null) throw new JSONException("No " + profileName(activeProfile) + " profile found.");
                RebuildCandidate c = new RebuildCandidate(); c.root = root; c.rawProfile = raw; c.profile = BackupCodec.parseProfile(activeProfile, raw);
                c.fileName = getDisplayName(uri); c.stamp = parseTimestamp(root.optString("exportedAt", ""));
                if (c.stamp <= 0) c.stamp = queryLastModified(uri);
                if (c.stamp <= 0) c.stamp = i;
                c.rawCycleId = raw.optString("cycleId", "").trim(); parsed.add(c);
            } catch (Exception ex) { errors.add(getDisplayName(uri) + ": " + messageOf(ex)); }
        }
        if (parsed.isEmpty()) { showMessage("No usable backups found. " + String.join("; ", errors), true); return; }
        parsed.sort(Comparator.comparingLong(c -> c.stamp));
        RebuildCandidate latest = parsed.get(parsed.size() - 1);
        List<RebuildCandidate> candidates = new ArrayList<>();
        if (!latest.rawCycleId.isEmpty()) {
            for (RebuildCandidate c : parsed) if (latest.rawCycleId.equals(c.rawCycleId)) candidates.add(c);
        } else {
            Double cap = latest.profile.initialCapital;
            for (RebuildCandidate c : parsed) {
                if (c.rawCycleId.isEmpty() && ((cap != null && c.profile.initialCapital != null && Math.abs(cap - c.profile.initialCapital) < 1e-8)
                        || (cap == null && c.profile.initialCapital == null))) candidates.add(c);
            }
        }
        if (candidates.isEmpty()) candidates.add(latest);
        Map<String, EventWithStamp> merged = new LinkedHashMap<>();
        for (RebuildCandidate candidate : candidates) {
            for (TradeEvent event : candidate.profile.events) {
                String id = event.id;
                EventWithStamp existing = merged.get(id);
                if (existing == null || candidate.stamp >= existing.stamp) merged.put(id, new EventWithStamp(event, candidate.stamp));
            }
        }
        ProfileData rebuilt = latest.profile.copyWithoutEvents();
        rebuilt.cycleId = latest.rawCycleId.isEmpty() ? UUID.randomUUID().toString() : latest.rawCycleId;
        if (latest.rawCycleId.isEmpty()) { rebuilt.initialCapital = null; rebuilt.targetProfit = ""; }
        for (EventWithStamp value : merged.values()) rebuilt.events.add(value.event);
        AccountSnapshot check = AccountEngine.calculate(rebuilt);
        if (check.error != null) { showMessage("Rebuild stopped. The current profile was left unchanged: " + check.error, true); return; }
        final int fileCount = uris.size(); final int recoveredEvents = rebuilt.events.size(); final int skipped = errors.size();
        String details = "Files selected: " + fileCount + "\nMatching snapshots merged: " + candidates.size()
                + "\nUnique events recovered: " + recoveredEvents
                + (skipped > 0 ? "\nUnreadable files skipped: " + skipped : "")
                + "\n\nOnly " + profileName(activeProfile) + " will be replaced. The other profile remains unchanged.";
        new AlertDialog.Builder(this).setTitle("Confirm rebuild").setMessage(details)
                .setNegativeButton("Cancel", null).setPositiveButton("Rebuild", (dialog, which) -> {
                    try { db.replaceProfile(rebuilt); afterDataChange(); expandedWeeks.clear(); showMessage("Rebuilt " + profileName(activeProfile) + " from " + candidates.size() + " matching backups; " + recoveredEvents + " unique events recovered.", false); refreshAll(); }
                    catch (Exception ex) { showMessage("Rebuild failed. Current profile was left unchanged: " + messageOf(ex), true); }
                }).show();
    }

    private String getDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return uri == null ? "backup" : uri.getLastPathSegment();
    }

    private long queryLastModified(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null)) {
            if (c != null && c.moveToFirst() && !c.isNull(0)) return c.getLong(0);
        } catch (Exception ignored) { }
        return 0L;
    }

    private static long parseTimestamp(String text) {
        if (text == null || text.isEmpty()) return 0L;
        try { return Instant.parse(text).toEpochMilli(); }
        catch (Exception ignored) { try { return java.time.OffsetDateTime.parse(text).toInstant().toEpochMilli(); } catch (Exception ex) { return 0L; } }
    }

    private void afterDataChange() { writeRecoverySnapshot(); }

    private void renderCurrentPanel() {
        if (db == null) return;
        content.removeAllViews(); ProfileData p = db.getProfile(activeProfile); AccountSnapshot d = AccountEngine.calculate(p);
        if ("goal".equals(activeTab)) renderGoal(p, d); else if ("forecast".equals(activeTab)) renderForecast(p, d); else renderLog(p, d);
    }

    private void showMessage(String message, boolean isError) {
        statusMessage = message == null ? "" : message; statusIsError = isError;
        if (messageView != null) {
            messageView.setText(statusMessage); messageView.setTextColor(isError ? RED : MINT);
            messageView.setVisibility(statusMessage.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    private void addSectionTitle(LinearLayout parent, String title, String subtitle) {
        LinearLayout c = column(); c.setPadding(dp(1), dp(6), dp(1), dp(9));
        c.addView(text(title, 19, TEXT, true)); TextView sub = text(subtitle, 11, MUTED, false); sub.setPadding(0, dp(3), 0, 0); c.addView(sub); parent.addView(c);
    }

    private void addCardMessage(LinearLayout parent, String title, String message, int accent) {
        LinearLayout c = card(); c.setBackground(round(CARD, dp(15), LINE, dp(1)));
        TextView h = text(title, 14, accent, true); c.addView(h);
        TextView body = text(message, 12, MUTED, false); body.setPadding(0, dp(5), 0, 0); c.addView(body);
        parent.addView(c); addGap(parent, 8);
    }

    private void addEstimateRow(LinearLayout parent, String title, String date, String detail, int color) {
        LinearLayout r = row(); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(7), 0, dp(7));
        LinearLayout labels = column(); labels.addView(text(title, 10, color, true));
        TextView sub = text(detail == null ? "" : detail, 10, MUTED, false); sub.setPadding(0, dp(3), 0, 0); labels.addView(sub);
        r.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView val = text(date == null ? "—" : date, 14, TEXT, true); val.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); val.setMaxWidth(dp(155)); r.addView(val);
        parent.addView(r);
    }

    private void addRowStat(LinearLayout parent, String label, String value, int color) {
        LinearLayout r = row(); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(7), 0, dp(7));
        r.addView(text(label, 10, MUTED, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = text(value, 14, color, true); v.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); r.addView(v); parent.addView(r);
    }

    private void addStatGrid(LinearLayout parent, String labelA, String valueA, int colorA, String labelB, String valueB, int colorB) {
        LinearLayout r = row();
        LinearLayout a = column(); a.setPadding(0, dp(8), dp(6), dp(8));
        a.addView(text(labelA, 9, MUTED, true)); TextView av = text(valueA, 15, colorA, true); av.setPadding(0, dp(4), 0, 0); a.addView(av);
        LinearLayout b = column(); b.setPadding(dp(6), dp(8), 0, dp(8));
        b.addView(text(labelB, 9, MUTED, true)); TextView bv = text(valueB, 15, colorB, true); bv.setPadding(0, dp(4), 0, 0); b.addView(bv);
        r.addView(a, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        View divider = new View(this); divider.setBackgroundColor(LINE); r.addView(divider, new LinearLayout.LayoutParams(dp(1), ViewGroup.LayoutParams.MATCH_PARENT));
        r.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); parent.addView(r);
    }

    private void addDivider(LinearLayout parent) {
        View v = new View(this); v.setBackgroundColor(LINE); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)); p.topMargin = dp(5); p.bottomMargin = dp(5); parent.addView(v, p);
    }

    private LinearLayout card() { LinearLayout c = column(); c.setBackground(round(CARD, dp(16), Color.TRANSPARENT, 0)); c.setPadding(dp(14), dp(13), dp(14), dp(13)); return c; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void addGap(LinearLayout parent, int dpValue) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(dpValue))); }
    private void addGapHorizontal(LinearLayout parent, int dpValue) { View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(dp(dpValue), 1)); }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); else t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return t;
    }

    private Button actionButton(String label, int background, int foreground) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(13); b.setTextColor(foreground); b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(round(background, dp(12), Color.TRANSPARENT, 0)); b.setMinHeight(dp(42)); b.setStateListAnimator(null); return b;
    }

    private Button smallButton(String label, int background, int foreground) {
        Button b = actionButton(label, background, foreground); b.setTextSize(11); b.setPadding(dp(7), 0, dp(7), 0); b.setMinWidth(dp(70)); b.setMinHeight(dp(37)); return b;
    }

    private EditText editText(String hint, int inputType) {
        EditText e = new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(119, 134, 155)); e.setTextColor(TEXT); e.setTextSize(16); e.setSingleLine(true); e.setInputType(inputType);
        e.setBackground(round(CARD_ALT, dp(11), LINE, dp(1))); e.setPadding(dp(12), dp(6), dp(12), dp(6)); return e;
    }

    private GradientDrawable round(int color, float radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, strokeColor); return d;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private String profileName(String id) { return "play".equals(id) ? "Play Money" : "Slow Growth"; }
    private boolean validTab(String value) { return "goal".equals(value) || "forecast".equals(value) || "log".equals(value); }
    private static final double EPSILON = 1e-8;

    private String money(double value, ProfileData p) {
        if (!Double.isFinite(value)) return "—";
        String n;
        if (Math.abs(value) >= 1e12 || (value != 0 && Math.abs(value) < 0.0001)) n = String.format(Locale.ENGLISH, "%.3e", value);
        else n = String.format(Locale.ENGLISH, "%,.2f", value);
        String currency = p == null || p.currency == null ? "€" : p.currency.trim();
        if (currency.isEmpty()) return n;
        if (currency.matches("^[A-Za-z€$£¥].*")) return currency + " " + n;
        return n + " " + currency;
    }

    private String signedMoney(double value, ProfileData p) {
        if (!Double.isFinite(value)) return "—";
        return (value > EPSILON ? "+" : value < -EPSILON ? "−" : "") + money(Math.abs(value), p);
    }

    private String percent(double value) { return Double.isFinite(value) ? String.format(Locale.ENGLISH, "%.1f%%", value * 100.0) : "—"; }

    private double parseAmount(String input) {
        if (input == null) return Double.NaN;
        String s = input.trim().replace(" ", "");
        if (s.isEmpty()) return Double.NaN;
        if (s.contains(",") && s.contains(".")) {
            if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(".", "").replace(',', '.');
            else s = s.replace(",", "");
        } else if (s.contains(",")) s = s.replace(',', '.');
        try { double v = Double.parseDouble(s); return Double.isFinite(v) ? v : Double.NaN; }
        catch (NumberFormatException ex) { return Double.NaN; }
    }

    private String formatDate(String iso, boolean weekday) {
        try {
            LocalDate date = LocalDate.parse(iso);
            return date.format(DateTimeFormatter.ofPattern(weekday ? "EEE, dd MMM yyyy" : "dd MMM yyyy", Locale.ENGLISH));
        } catch (Exception ex) { return iso == null ? "—" : iso; }
    }

    private String eventLabel(String kind) {
        switch (kind) {
            case "win": return "WIN";
            case "loss": return "LOSS";
            case "add": return "MANUAL  ＋";
            case "subtract": return "MANUAL  −";
            default: return "EVENT";
        }
    }

    private int eventColor(String kind) {
        if ("win".equals(kind)) return GREEN;
        if ("loss".equals(kind)) return RED;
        if ("add".equals(kind)) return MINT;
        return MUTED;
    }

    private String messageOf(Throwable ex) {
        if (ex == null) return "Unknown error.";
        String text = ex.getMessage();
        if (text == null || text.trim().isEmpty()) return ex.getClass().getSimpleName();
        return text;
    }

    private static final class WeekBucket {
        final String key;
        final int year, month, week;
        final String label;
        final List<TradeEvent> events = new ArrayList<>();
        WeekBucket(String key, int year, int month, int week, String label) { this.key = key; this.year = year; this.month = month; this.week = week; this.label = label; }
    }

    @Override protected void onDestroy() {
        if (db != null) { try { db.close(); } catch (Exception ignored) { } }
        super.onDestroy();
    }
}
