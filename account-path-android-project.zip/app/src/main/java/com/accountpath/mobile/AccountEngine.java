package com.accountpath.mobile;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Pure calculation logic. It has no Android or database dependencies. */
public final class AccountEngine {
    private static final double EPS = 1e-8;
    private AccountEngine() {}

    public static AccountSnapshot calculate(ProfileData profile) {
        AccountSnapshot out = new AccountSnapshot();
        if (profile == null || profile.initialCapital == null
                || !Double.isFinite(profile.initialCapital) || profile.initialCapital <= 0.0) {
            return out;
        }
        out.isSet = true;
        out.initialCapital = profile.initialCapital;
        out.balance = profile.initialCapital;
        out.modelBalance = profile.initialCapital;

        List<TradeEvent> ordered = new ArrayList<>(profile.events);
        ordered.sort(Comparator.comparing((TradeEvent e) -> e.date)
                .thenComparingLong(e -> e.createdAt)
                .thenComparing(e -> e.id));

        for (TradeEvent event : ordered) {
            if (event == null || !event.isValid()) {
                out.error = "An event has an invalid amount, date or type. The profile was not changed.";
                return out;
            }
            if (("loss".equals(event.kind) || "subtract".equals(event.kind))
                    && event.amount > out.balance + EPS) {
                out.error = "The history would take the visible account total below zero on "
                        + event.date + ". Correct or remove the event.";
                return out;
            }
            double before = out.balance;
            double modelReturn = Double.NaN;
            if ("win".equals(event.kind)) {
                out.balance += event.amount;
                out.netTrading += event.amount;
                out.wins++;
                out.winAmounts.add(event.amount);
                if (out.modelBalance > EPS) {
                    modelReturn = Math.log((out.modelBalance + event.amount) / out.modelBalance);
                    out.modelBalance += event.amount;
                } else {
                    out.modelBalance += event.amount;
                }
            } else if ("loss".equals(event.kind)) {
                out.balance -= event.amount;
                out.netTrading -= event.amount;
                out.losses++;
                out.lossAmounts.add(event.amount);
                if (out.modelBalance > EPS) {
                    double after = Math.max(1e-8, out.modelBalance - event.amount);
                    modelReturn = Math.log(after / out.modelBalance);
                    out.modelBalance = Math.max(0.0, out.modelBalance - event.amount);
                }
            } else if ("add".equals(event.kind)) {
                out.balance += event.amount;
                out.netManual += event.amount;
                out.manualAdds += event.amount;
            } else if ("subtract".equals(event.kind)) {
                out.balance -= event.amount;
                out.netManual -= event.amount;
                out.manualSubs += event.amount;
            }
            if (out.balance < 0 && out.balance > -EPS) out.balance = 0;
            out.sortedEvents.add(event);
            out.balanceAfterByEvent.put(event.id, out.balance);
            out.modelBalanceAfterByEvent.put(event.id, out.modelBalance);
            if (("win".equals(event.kind) || "loss".equals(event.kind)) && Double.isFinite(modelReturn)) {
                out.returns.add(new AccountSnapshot.ReturnSample(modelReturn, event.date,
                        event.id, event.amount, event.kind));
            }
            if (!Double.isFinite(before) || !Double.isFinite(out.balance) || !Double.isFinite(out.modelBalance)) {
                out.error = "A calculation exceeded the supported numeric range.";
                return out;
            }
        }
        return out;
    }
}
