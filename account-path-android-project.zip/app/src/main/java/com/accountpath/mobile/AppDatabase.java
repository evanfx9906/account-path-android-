package com.accountpath.mobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Private on-device SQLite store. All write operations use transactions. */
public final class AppDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "account_path_local.db";
    private static final int DB_VERSION = 1;

    public AppDatabase(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
        try { db.execSQL("PRAGMA synchronous=FULL"); } catch (SQLiteException ignored) { }
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE profiles (id TEXT PRIMARY KEY NOT NULL, initial_capital REAL NULL, currency TEXT NOT NULL DEFAULT '€', target_profit TEXT NOT NULL DEFAULT '', cycle_id TEXT NOT NULL, updated_at INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE events (profile_id TEXT NOT NULL, cycle_id TEXT NOT NULL, id TEXT NOT NULL, date TEXT NOT NULL, kind TEXT NOT NULL, amount REAL NOT NULL CHECK(amount > 0), created_at INTEGER NOT NULL, PRIMARY KEY(profile_id, id), FOREIGN KEY(profile_id) REFERENCES profiles(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX events_profile_date_idx ON events(profile_id, cycle_id, date, created_at)");
        db.execSQL("CREATE TABLE app_meta (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL)");
        ContentValues m = new ContentValues(); m.put("key", "generation"); m.put("value", "0"); db.insertOrThrow("app_meta", null, m);
        long now = System.currentTimeMillis();
        insertDefaultProfile(db, "slow", now);
        insertDefaultProfile(db, "play", now);
    }

    private void insertDefaultProfile(SQLiteDatabase db, String id, long now) {
        ContentValues v = new ContentValues(); v.put("id", id); v.putNull("initial_capital");
        v.put("currency", "€"); v.put("target_profit", ""); v.put("cycle_id", UUID.randomUUID().toString()); v.put("updated_at", now);
        db.insertOrThrow("profiles", null, v);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Schema migrations are added here when the first production schema needs an upgrade.
        throw new IllegalStateException("No migration path exists from database schema " + oldVersion + " to " + newVersion + ".");
    }

    public synchronized ProfileData getProfile(String id) {
        SQLiteDatabase db = getReadableDatabase();
        ProfileData p = null;
        try (Cursor c = db.query("profiles", new String[]{"id", "initial_capital", "currency", "target_profit", "cycle_id"}, "id=?", new String[]{id}, null, null, null)) {
            if (c.moveToFirst()) {
                p = new ProfileData(c.getString(0));
                p.initialCapital = c.isNull(1) ? null : c.getDouble(1);
                p.currency = c.getString(2);
                p.targetProfit = c.getString(3);
                p.cycleId = c.getString(4);
            }
        }
        if (p == null) return new ProfileData(id);
        try (Cursor c = db.query("events", new String[]{"id", "date", "kind", "amount", "created_at"}, "profile_id=? AND cycle_id=?", new String[]{id, p.cycleId}, null, null, "date ASC, created_at ASC, id ASC")) {
            while (c.moveToNext()) p.events.add(new TradeEvent(c.getString(0), c.getString(1), c.getString(2), c.getDouble(3), c.getLong(4)));
        }
        return p;
    }

    public synchronized List<ProfileData> getAllProfiles() {
        List<ProfileData> all = new ArrayList<>();
        all.add(getProfile("slow")); all.add(getProfile("play"));
        return all;
    }

    public synchronized long getGeneration() {
        try (Cursor c = getReadableDatabase().query("app_meta", new String[]{"value"}, "key='generation'", null, null, null, null)) {
            if (c.moveToFirst()) return parseLong(c.getString(0), 0L);
        }
        return 0L;
    }

    private long getGeneration(SQLiteDatabase db) {
        try (Cursor c = db.query("app_meta", new String[]{"value"}, "key='generation'", null, null, null, null)) {
            if (c.moveToFirst()) return parseLong(c.getString(0), 0L);
        }
        return 0L;
    }

    private void setGeneration(SQLiteDatabase db, long generation) {
        ContentValues v = new ContentValues(); v.put("value", Long.toString(Math.max(0, generation)));
        db.update("app_meta", v, "key='generation'", null);
    }

    private void bumpGeneration(SQLiteDatabase db) { setGeneration(db, getGeneration(db) + 1L); }
    private static long parseLong(String value, long fallback) { try { return Long.parseLong(value); } catch (RuntimeException ex) { return fallback; } }

    public synchronized void setStartingCapital(String id, double capital, String currency) {
        if (!Double.isFinite(capital) || capital <= 0.0) throw new IllegalArgumentException("Enter starting capital greater than zero.");
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ProfileData old = getProfileInsideTransaction(db, id);
            if (old.initialCapital != null) throw new IllegalStateException("Starting capital is already locked for this cycle. Use Blown Account to start again.");
            ContentValues v = new ContentValues(); v.put("initial_capital", capital); v.put("currency", cleanCurrency(currency)); v.put("updated_at", System.currentTimeMillis());
            db.update("profiles", v, "id=?", new String[]{id}); bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void setTargetProfit(String id, String target) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ContentValues v = new ContentValues(); v.put("target_profit", target == null ? "" : target.trim()); v.put("updated_at", System.currentTimeMillis());
            if (db.update("profiles", v, "id=?", new String[]{id}) != 1) throw new IllegalStateException("Profile not found.");
            bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void addEvent(String id, TradeEvent event) {
        if (event == null || !event.isValid()) throw new IllegalArgumentException("Enter a valid date and amount greater than zero.");
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ProfileData current = getProfileInsideTransaction(db, id);
            if (current.initialCapital == null) throw new IllegalStateException("Set starting capital first.");
            AccountSnapshot before = AccountEngine.calculate(current);
            if (before.error != null) throw new IllegalStateException(before.error);
            if ("loss".equals(event.kind) || "subtract".equals(event.kind)) {
                if (event.amount > before.balance + 1e-8) throw new IllegalArgumentException("That amount exceeds the current account total.");
                if ("subtract".equals(event.kind) && Math.abs(event.amount - before.balance) < 1e-8)
                    throw new IllegalStateException("EMPTY_BALANCE_CONFIRMATION");
            }
            ContentValues v = new ContentValues(); v.put("profile_id", id); v.put("cycle_id", current.cycleId); v.put("id", event.id);
            v.put("date", event.date); v.put("kind", event.kind); v.put("amount", event.amount); v.put("created_at", event.createdAt);
            db.insertOrThrow("events", null, v);
            ProfileData afterProfile = getProfileInsideTransaction(db, id);
            AccountSnapshot after = AccountEngine.calculate(afterProfile);
            if (after.error != null) throw new IllegalStateException(after.error);
            bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void deleteEvent(String profileId, String eventId) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ProfileData p = getProfileInsideTransaction(db, profileId);
            int removed = db.delete("events", "profile_id=? AND cycle_id=? AND id=?", new String[]{profileId, p.cycleId, eventId});
            if (removed == 0) { db.setTransactionSuccessful(); return; }
            AccountSnapshot check = AccountEngine.calculate(getProfileInsideTransaction(db, profileId));
            if (check.error != null) throw new IllegalStateException(check.error);
            bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void resetCycle(String id) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            ProfileData old = getProfileInsideTransaction(db, id);
            db.delete("events", "profile_id=?", new String[]{id});
            ContentValues v = new ContentValues(); v.putNull("initial_capital"); v.put("target_profit", "");
            v.put("cycle_id", UUID.randomUUID().toString()); v.put("updated_at", System.currentTimeMillis());
            if (db.update("profiles", v, "id=?", new String[]{id}) != 1) throw new IllegalStateException("Profile not found.");
            bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void replaceProfile(ProfileData p) {
        if (p == null) throw new IllegalArgumentException("No profile data.");
        AccountSnapshot check = AccountEngine.calculate(p);
        if (check.error != null) throw new IllegalArgumentException(check.error);
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            upsertProfile(db, p);
            db.delete("events", "profile_id=?", new String[]{p.id});
            insertEvents(db, p);
            bumpGeneration(db); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void replaceAllProfiles(List<ProfileData> profiles, long sourceGeneration) {
        ProfileData slow = find(profiles, "slow"), play = find(profiles, "play");
        if (slow == null || play == null) throw new IllegalArgumentException("Backup must contain both profiles.");
        if (AccountEngine.calculate(slow).error != null) throw new IllegalArgumentException(AccountEngine.calculate(slow).error);
        if (AccountEngine.calculate(play).error != null) throw new IllegalArgumentException(AccountEngine.calculate(play).error);
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try {
            upsertProfile(db, slow); upsertProfile(db, play);
            db.delete("events", null, null);
            insertEvents(db, slow); insertEvents(db, play);
            long next = Math.max(getGeneration(db) + 1L, sourceGeneration + 1L);
            setGeneration(db, next); db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void replaceAllProfiles(List<ProfileData> profiles) { replaceAllProfiles(profiles, 0L); }

    private static ProfileData find(List<ProfileData> profiles, String id) {
        if (profiles == null) return null;
        for (ProfileData p : profiles) if (p != null && id.equals(p.id)) return p;
        return null;
    }

    private void upsertProfile(SQLiteDatabase db, ProfileData p) {
        ContentValues v = new ContentValues(); v.put("id", p.id);
        if (p.initialCapital == null) v.putNull("initial_capital"); else v.put("initial_capital", p.initialCapital);
        v.put("currency", cleanCurrency(p.currency)); v.put("target_profit", p.targetProfit == null ? "" : p.targetProfit);
        v.put("cycle_id", p.cycleId == null || p.cycleId.isEmpty() ? UUID.randomUUID().toString() : p.cycleId); v.put("updated_at", System.currentTimeMillis());
        db.insertWithOnConflict("profiles", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    private void insertEvents(SQLiteDatabase db, ProfileData p) {
        String cycle = p.cycleId == null || p.cycleId.isEmpty() ? "legacy-cycle" : p.cycleId;
        for (TradeEvent e : p.events) {
            if (e == null || !e.isValid()) throw new IllegalArgumentException("Backup contains an invalid event.");
            ContentValues v = new ContentValues(); v.put("profile_id", p.id); v.put("cycle_id", cycle); v.put("id", e.id);
            v.put("date", e.date); v.put("kind", e.kind); v.put("amount", e.amount); v.put("created_at", e.createdAt);
            db.insertOrThrow("events", null, v);
        }
    }

    public synchronized void restoreGenerationAtLeast(long generation) {
        SQLiteDatabase db = getWritableDatabase(); db.beginTransaction();
        try { setGeneration(db, Math.max(getGeneration(db), generation)); db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }

    private ProfileData getProfileInsideTransaction(SQLiteDatabase db, String id) {
        ProfileData p = null;
        try (Cursor c = db.query("profiles", new String[]{"id", "initial_capital", "currency", "target_profit", "cycle_id"}, "id=?", new String[]{id}, null, null, null)) {
            if (c.moveToFirst()) {
                p = new ProfileData(c.getString(0)); p.initialCapital = c.isNull(1) ? null : c.getDouble(1);
                p.currency = c.getString(2); p.targetProfit = c.getString(3); p.cycleId = c.getString(4);
            }
        }
        if (p == null) throw new IllegalStateException("Profile not found: " + id);
        try (Cursor c = db.query("events", new String[]{"id", "date", "kind", "amount", "created_at"}, "profile_id=? AND cycle_id=?", new String[]{id, p.cycleId}, null, null, "date ASC, created_at ASC, id ASC")) {
            while (c.moveToNext()) p.events.add(new TradeEvent(c.getString(0), c.getString(1), c.getString(2), c.getDouble(3), c.getLong(4)));
        }
        return p;
    }

    private static String cleanCurrency(String value) {
        String s = value == null ? "€" : value.trim(); if (s.isEmpty()) s = "€"; return s.length() > 8 ? s.substring(0, 8) : s;
    }
}
