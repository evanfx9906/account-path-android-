package com.accountpath.mobile;

import org.junit.Test;
import java.time.LocalDate;
import static org.junit.Assert.*;

public class ForecastEngineTest {
    @Test public void datedPaceRequiresEnoughCalendarHistory() {
        ProfileData p = new ProfileData("slow"); p.initialCapital = 10000.0;
        LocalDate start = LocalDate.now().minusDays(45);
        for (int i = 0; i < 22; i++) {
            LocalDate day = start.plusDays(i * 2L);
            p.events.add(new TradeEvent("e" + i, day.toString(), i % 2 == 0 ? "win" : "loss", i % 2 == 0 ? 350 : 180, i));
        }
        AccountSnapshot d = AccountEngine.calculate(p);
        ForecastEngine.Cadence cadence = ForecastEngine.cadence(d);
        assertTrue(cadence.ready);
        assertTrue(cadence.uniqueDates >= 3);
        assertTrue(cadence.spanDays >= 14);
        assertTrue(cadence.tradesPerWeek > 0);
    }

    @Test public void modelStatsRespectOutcomeCounts() {
        ProfileData p = new ProfileData("play"); p.initialCapital = 1000.0;
        p.events.add(new TradeEvent("a", LocalDate.now().minusDays(3).toString(), "win", 100, 1));
        p.events.add(new TradeEvent("b", LocalDate.now().minusDays(2).toString(), "loss", 40, 2));
        p.events.add(new TradeEvent("c", LocalDate.now().minusDays(1).toString(), "add", 1000, 3));
        AccountSnapshot d = AccountEngine.calculate(p);
        ForecastEngine.Stats s = ForecastEngine.stats(p, d);
        assertEquals(2, s.outcomes);
        assertEquals(1, s.wins);
        assertEquals(1, s.losses);
        assertEquals(0.5, s.winRate, 1e-8);
        assertEquals(2, d.returns.size());
    }
}
