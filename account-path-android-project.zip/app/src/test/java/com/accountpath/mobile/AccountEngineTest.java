package com.accountpath.mobile;

import org.junit.Test;
import static org.junit.Assert.*;

public class AccountEngineTest {
    @Test public void manualEventsChangeBalanceButNotTrainingResults() {
        ProfileData p = new ProfileData("slow");
        p.initialCapital = 100.0;
        p.events.add(new TradeEvent("1", "2026-01-05", "win", 20.0, 1));
        p.events.add(new TradeEvent("2", "2026-01-06", "add", 500.0, 2));
        p.events.add(new TradeEvent("3", "2026-01-07", "loss", 10.0, 3));
        p.events.add(new TradeEvent("4", "2026-01-08", "subtract", 25.0, 4));
        AccountSnapshot d = AccountEngine.calculate(p);
        assertNull(d.error);
        assertEquals(585.0, d.balance, 1e-8);
        assertEquals(110.0, d.modelBalance, 1e-8);
        assertEquals(2, d.returns.size());
        assertEquals(1, d.wins);
        assertEquals(1, d.losses);
        assertEquals(10.0, d.netTrading, 1e-8);
        assertEquals(475.0, d.netManual, 1e-8);
    }

    @Test public void negativeBalanceIsRejected() {
        ProfileData p = new ProfileData("play");
        p.initialCapital = 10.0;
        p.events.add(new TradeEvent("1", "2026-01-05", "loss", 11.0, 1));
        assertNotNull(AccountEngine.calculate(p).error);
    }

    @Test public void invalidDateIsRejectedRatherThanSilentlyChanged() {
        ProfileData p = new ProfileData("slow");
        p.initialCapital = 100.0;
        p.events.add(new TradeEvent("bad-date", "2026-02-30", "win", 10.0, 1));
        assertNotNull(AccountEngine.calculate(p).error);
    }

    @Test public void eventsAreCalculatedInDateOrder() {
        ProfileData p = new ProfileData("slow");
        p.initialCapital = 100.0;
        p.events.add(new TradeEvent("later", "2026-01-08", "win", 20.0, 1));
        p.events.add(new TradeEvent("earlier", "2026-01-07", "loss", 10.0, 2));
        AccountSnapshot d = AccountEngine.calculate(p);
        assertNull(d.error);
        assertEquals("earlier", d.sortedEvents.get(0).id);
        assertEquals(110.0, d.balance, 1e-8);
    }
}
